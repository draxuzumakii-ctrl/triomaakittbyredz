# TRIOMA Home Kit

Satu jaringan, tiga fungsi: otomatisasi, keamanan, efisiensi energi.
Next.js 15 (App Router) + TypeScript + Tailwind + Framer Motion + Supabase (PostgreSQL, Auth, Realtime, Storage, RLS).

## Menjalankan

1. `npm install`
2. Buat proyek di Supabase, lalu salin `.env.example` menjadi `.env.local` dan isi URL serta anon key.
3. Supabase -> SQL Editor: jalankan seluruh isi `supabase/migrations/001_schema.sql`
   (tabel, constraint, RLS, fungsi `place_order`, bucket `product-images`, dan katalog awal).
4. Authentication -> Providers -> Email. Untuk uji coba lokal, matikan "Confirm email" agar pendaftaran langsung masuk.
5. `npm run dev` lalu buka http://localhost:3000

## Membuat Super Admin pertama

Daftar lewat `/auth/register`, lalu jalankan di SQL Editor (diizinkan karena tanpa sesi pengguna):

```sql
update profiles set role = 'super_admin' where id = (select id from auth.users where email = 'EMAIL-ANDA');
```

Super Admin kemudian dapat mengubah role pengguna lain di `/admin/users`.
Isi nomor WhatsApp kasir di `/admin/config` agar tombol WhatsApp muncul.

## Struktur

```
supabase/migrations/001_schema.sql   skema, RLS, fungsi, data awal
src/app/(public)                     Home, Produk (+detail & pemesanan), Teknologi, Cara Kerja, Tentang, Kontak
src/app/auth                         Masuk, Daftar, aksi server
src/app/dashboard                    Beranda, Perangkat, Ruangan, Otomatisasi, Keamanan, Energi, Riwayat, Notifikasi, Pesanan, Pengaturan
src/app/admin                        Ikhtisar, Produk, Paket, Pesanan, Pengguna, Perangkat, Pemantauan, Pengumuman, Konfigurasi
src/components                       ui/ (kaca, toast, form aksi), site/, dash/, admin/
src/lib                              supabase client, auth guard, validasi zod, format
```

## Keputusan penting

- **Simulation Mode jujur.** Perangkat dan data simulasi ditandai `is_simulated` di database dan selalu diberi label "Simulasi" di UI.
  Perangkat fisik berstatus "Belum terhubung" dan tidak dapat dikendalikan sampai hub tersedia. Dashboard tidak pernah mengklaim hub terhubung tanpa perangkat fisik.
- **HPP tidak pernah publik.** Disimpan di tabel terpisah `product_costs` (RLS hanya admin).
- **Harga dari database.** `place_order()` memotong stok secara atomik dan menghitung total di server; klien tidak bisa mengirim harga.
- **Role.** Trigger database mencegah eskalasi role; hanya Super Admin yang dapat mengubahnya.
- **Tidak ada angka fiktif.** Statistik admin dihitung langsung dari tabel.

## Perlu diperiksa sebelum produksi

- Isi paket, spesifikasi, dan stok awal di data seed adalah titik awal. Koreksi lewat Admin -> Paket / Produk.
- Foto produk belum ada; unggah lewat Admin -> Produk -> Edit.
- Kode ini ditulis tanpa akses jaringan sehingga belum pernah dijalankan (`npm install`, `next build`) dan belum diuji terhadap Supabase sungguhan. Jalankan `npm run typecheck` dan uji alur pendaftaran, pesanan, dan simulasi sebelum dipakai.

## Tahap berikutnya: ESP32-S3 dan Zigbee

Perangkat fisik cukup menulis ke tabel `devices` (kolom `state`, `is_online`, `last_seen`) dan `activity_logs` (`source = 'device'`) dengan `is_simulated = false`.
UI sudah memisahkan sumber data, dan Realtime sudah berlangganan perubahan `devices`, `notifications`, dan `activity_logs`.
Disarankan menambah jalur pairing (kode hub per pengguna) dan endpoint ingest berautentikasi sebelum menghubungkan perangkat nyata.

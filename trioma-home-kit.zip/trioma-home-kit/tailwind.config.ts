import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        obsidian: "#080A0F",
        graphite: "#11151D",
        electric: "#6A9FFF",
        silver: "#C9D0DC",
      },
      fontFamily: {
        sans: ["var(--font-geist-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-geist-mono)", "ui-monospace", "monospace"],
      },
      letterSpacing: { display: "-0.045em" },
    },
  },
  plugins: [],
};
export default config;

"use client";
import { motion } from "framer-motion";

/**
 * Visual orisinal: tiga lapisan kaca (Otomatisasi, Keamanan, Energi) bertumpuk
 * dalam perspektif isometrik, dihubungkan satu garis cahaya = "satu jaringan".
 */
export function HeroVisual() {
  const layers = [
    { y: 250, label: "Energi", tint: "rgba(201,208,220,.10)" },
    { y: 150, label: "Keamanan", tint: "rgba(106,159,255,.10)" },
    { y: 50, label: "Otomatisasi", tint: "rgba(106,159,255,.16)" },
  ];
  const slab = (y: number) => `M300 ${y} L520 ${y + 70} L300 ${y + 140} L80 ${y + 70} Z`;
  return (
    <svg viewBox="0 0 600 460" className="h-auto w-full" role="img" aria-label="Tiga lapisan TRIOMA Home Kit terhubung oleh satu jaringan cahaya">
      <defs>
        <linearGradient id="edge" x1="0" x2="1"><stop offset="0" stopColor="#fff" stopOpacity=".5" /><stop offset="1" stopColor="#fff" stopOpacity=".08" /></linearGradient>
        <radialGradient id="core"><stop offset="0" stopColor="#6A9FFF" /><stop offset="1" stopColor="#6A9FFF" stopOpacity="0" /></radialGradient>
        <filter id="soft"><feGaussianBlur stdDeviation="6" /></filter>
      </defs>
      <ellipse cx="300" cy="430" rx="190" ry="22" fill="#6A9FFF" opacity=".16" filter="url(#soft)" />
      {layers.map((l, i) => (
        <motion.g key={l.label} initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 + i * 0.12, duration: 0.8, ease: [0.2, 0.7, 0.2, 1] }}>
          <path d={slab(l.y)} fill={l.tint} stroke="url(#edge)" strokeWidth="1.2" />
          <path d={`M80 ${l.y + 70} L80 ${l.y + 86} L300 ${l.y + 156} L300 ${l.y + 140}`} fill="rgba(255,255,255,.05)" stroke="rgba(255,255,255,.12)" />
          <path d={`M520 ${l.y + 70} L520 ${l.y + 86} L300 ${l.y + 156} L300 ${l.y + 140}`} fill="rgba(255,255,255,.025)" stroke="rgba(255,255,255,.1)" />
          <text x="318" y={l.y + 120} fill="#C9D0DC" fontSize="13" opacity=".85">{l.label}</text>
        </motion.g>
      ))}
      {/* garis jaringan tunggal */}
      <motion.path d="M300 120 L300 220 L300 320" stroke="#6A9FFF" strokeWidth="2" strokeLinecap="round" strokeDasharray="4 7"
        initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: 0.8, duration: 1.1 }} />
      {[120, 220, 320].map((y, i) => (
        <g key={y}>
          <circle cx="300" cy={y} r="22" fill="url(#core)" opacity=".7" />
          <circle cx="300" cy={y} r="5" fill="#fff" />
          <circle cx="300" cy={y} r="9" fill="none" stroke="#6A9FFF" strokeOpacity=".7">
            <animate attributeName="r" values="7;16;7" dur="3.2s" begin={`${i * 0.5}s`} repeatCount="indefinite" />
            <animate attributeName="stroke-opacity" values=".8;0;.8" dur="3.2s" begin={`${i * 0.5}s`} repeatCount="indefinite" />
          </circle>
        </g>
      ))}
    </svg>
  );
}

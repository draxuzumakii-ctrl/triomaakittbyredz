"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { SimBadge } from "@/components/ui/bits";
import { cn } from "@/lib/format";

/** Pratinjau interaktif. Seluruhnya simulasi di browser; tidak ada sensor yang dibaca. */
export function SmartHomePreview() {
  const [mode, setMode] = useState<"pulang" | "pergi">("pulang");
  const [lamp, setLamp] = useState(true);
  const away = mode === "pergi";
  const lampOn = lamp && !away;
  const rows = [
    { name: "Sensor Pintu", value: away ? "Siaga" : "Nonaktif" },
    { name: "Sensor Gerak", value: away ? "Siaga" : "Nonaktif" },
    { name: "Smart Switch Teras", value: lampOn ? "Menyala" : "Mati" },
  ];
  return (
    <div className="glass lit grid gap-8 p-6 md:grid-cols-[1.1fr_1fr] md:p-10">
      <div>
        <div className="flex items-center gap-3"><h3 className="text-xl font-medium tracking-tight">Coba Mode Pergi dan Mode Pulang</h3><SimBadge /></div>
        <p className="prose-tight mt-2 text-sm">Pratinjau ini berjalan di browser Anda. Tidak ada perangkat fisik yang terhubung.</p>
        <div className="mt-6 inline-flex rounded-full border border-white/10 bg-white/5 p-1" role="tablist" aria-label="Mode rumah">
          {(["pulang", "pergi"] as const).map((m) => (
            <button key={m} role="tab" aria-selected={mode === m} onClick={() => setMode(m)}
              className={cn("rounded-full px-5 py-2 text-sm transition-colors", mode === m ? "bg-electric text-[#06101f] font-semibold" : "text-silver")}>
              Mode {m === "pergi" ? "Pergi" : "Pulang"}
            </button>
          ))}
        </div>
        <ul className="mt-6 divide-y divide-white/[.08]">
          {rows.map((r) => (
            <li key={r.name} className="flex items-center justify-between py-3 text-sm">
              <span>{r.name}</span>
              <span className={cn("flex items-center gap-2", r.value === "Menyala" || r.value === "Siaga" ? "text-[var(--ok)]" : "text-silver/70")}>
                <span className={cn("dot", (r.value === "Menyala" || r.value === "Siaga") && "dot-ok")} />{r.value}
              </span>
            </li>
          ))}
        </ul>
        <button className="btn btn-glass btn-sm mt-4" onClick={() => setLamp((v) => !v)} disabled={away}>Ubah Smart Switch</button>
      </div>
      <div className="relative grid min-h-[240px] place-items-center overflow-hidden rounded-2xl border border-white/[.08] bg-[#0b0e15]">
        <motion.div animate={{ opacity: lampOn ? 1 : 0.18, scale: lampOn ? 1 : 0.85 }} transition={{ duration: 0.5 }}
          className="absolute h-56 w-56 rounded-full bg-[radial-gradient(circle,rgba(255,214,140,.55),transparent_68%)]" />
        <svg viewBox="0 0 200 160" className="relative w-4/5" aria-hidden>
          <path d="M20 80 100 20l80 60" fill="none" stroke="#C9D0DC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M36 74v70h128V74" fill="none" stroke="#C9D0DC" strokeWidth="2" strokeLinejoin="round" />
          <rect x="88" y="100" width="24" height="44" rx="3" fill="none" stroke="#6A9FFF" strokeWidth="2" />
          <circle cx="100" cy="60" r="7" fill={lampOn ? "#ffd68c" : "none"} stroke="#C9D0DC" strokeWidth="2" />
        </svg>
        <p className="absolute bottom-3 left-4 text-xs text-silver/70">{away ? "Rumah dalam Mode Pergi" : "Rumah dalam Mode Pulang"}</p>
      </div>
    </div>
  );
}

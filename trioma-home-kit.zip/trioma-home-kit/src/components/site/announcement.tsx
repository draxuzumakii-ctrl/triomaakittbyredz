import { createClient } from "@/lib/supabase/server";

export async function Announcement() {
  const supabase = await createClient();
  const { data } = await supabase.from("system_settings").select("value").eq("key", "announcement").maybeSingle();
  const v = data?.value as { active?: boolean; text?: string } | undefined;
  if (!v?.active || !v.text) return null;
  return (
    <div className="bg-electric/15 px-4 py-2 text-center text-sm text-[#cfe0ff]" role="status">{v.text}</div>
  );
}

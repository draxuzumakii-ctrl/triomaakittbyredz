import Link from "next/link";

export function Logo({ href = "/" }: { href?: string }) {
  return (
    <Link href={href} className="flex items-center gap-2.5" aria-label="TRIOMA Home Kit">
      <svg width="26" height="26" viewBox="0 0 26 26" fill="none" aria-hidden>
        <path d="M3 13 13 4l10 9" stroke="#6A9FFF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M7 12v9h12v-9" stroke="#C9D0DC" strokeWidth="2" strokeLinejoin="round" />
        <circle cx="13" cy="16" r="1.8" fill="#6A9FFF" />
      </svg>
      <span className="text-[15px] font-semibold tracking-[0.12em]">TRIOMA</span>
    </Link>
  );
}

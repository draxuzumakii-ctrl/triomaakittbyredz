"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Logo } from "./logo";
import { cn } from "@/lib/format";

const links = [
  { href: "/", label: "Beranda" },
  { href: "/products", label: "Produk" },
  { href: "/technology", label: "Teknologi" },
  { href: "/how-it-works", label: "Cara Kerja" },
  { href: "/about", label: "Tentang" },
  { href: "/contact", label: "Kontak" },
];

export function SiteNav({ signedIn }: { signedIn: boolean }) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const active = (h: string) => (h === "/" ? path === "/" : path.startsWith(h));
  return (
    <header className="sticky top-3 z-50 px-3 md:px-6">
      <nav className="glass mx-auto flex max-w-6xl items-center justify-between !rounded-full px-4 py-2.5 md:px-6" aria-label="Navigasi utama">
        <Logo />
        <ul className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <li key={l.href}>
              <Link href={l.href} aria-current={active(l.href) ? "page" : undefined}
                className={cn("rounded-full px-3.5 py-2 text-sm transition-colors", active(l.href) ? "bg-white/10 text-white" : "text-silver hover:text-white")}>
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-2">
          <Link href={signedIn ? "/dashboard" : "/auth/login"} className="btn btn-glass btn-sm">{signedIn ? "Dashboard" : "Masuk"}</Link>
          <button className="grid h-9 w-9 place-items-center rounded-full md:hidden" aria-label={open ? "Tutup menu" : "Buka menu"} aria-expanded={open} onClick={() => setOpen(!open)}>
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>
      {open && (
        <div className="glass mx-auto mt-2 max-w-6xl p-3 md:hidden">
          {links.map((l) => (
            <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className={cn("block rounded-xl px-4 py-3 text-base", active(l.href) ? "bg-white/10" : "text-silver")}>{l.label}</Link>
          ))}
          {!signedIn && <Link href="/auth/register" onClick={() => setOpen(false)} className="btn btn-primary mt-2 w-full">Buat akun</Link>}
        </div>
      )}
    </header>
  );
}

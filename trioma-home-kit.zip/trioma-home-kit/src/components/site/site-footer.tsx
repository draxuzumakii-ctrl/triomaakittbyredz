import Link from "next/link";
import { Logo } from "./logo";

export function SiteFooter() {
  return (
    <footer className="hairline mt-32 border-t">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="prose-tight mt-4 text-sm">TRIOMA Home Kit. Satu jaringan, tiga fungsi: otomatisasi, keamanan, dan efisiensi energi.</p>
        </div>
        <div className="text-sm">
          <p className="mb-3 font-medium">Jelajahi</p>
          <ul className="space-y-2 text-silver">
            <li><Link href="/products" className="hover:text-white">Produk</Link></li>
            <li><Link href="/technology" className="hover:text-white">Teknologi</Link></li>
            <li><Link href="/how-it-works" className="hover:text-white">Cara kerja</Link></li>
          </ul>
        </div>
        <div className="text-sm">
          <p className="mb-3 font-medium">Akun</p>
          <ul className="space-y-2 text-silver">
            <li><Link href="/auth/login" className="hover:text-white">Masuk</Link></li>
            <li><Link href="/auth/register" className="hover:text-white">Daftar</Link></li>
            <li><Link href="/contact" className="hover:text-white">Hubungi kami</Link></li>
          </ul>
        </div>
      </div>
      <p className="hairline border-t py-5 text-center text-xs text-silver/60">TRIOMA Home Kit</p>
    </footer>
  );
}

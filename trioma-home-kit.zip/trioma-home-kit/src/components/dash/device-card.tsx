"use client";
import { Activity, DoorClosed, DoorOpen, Thermometer, Plug, Video, Trash2 } from "lucide-react";
import { ActionButton, ToggleSwitch } from "@/components/ui/action-form";
import { SimBadge } from "@/components/ui/bits";
import { deviceLabel, timeAgo, cn } from "@/lib/format";
import { deleteDevice, setSwitch, setCamRecording } from "@/app/dashboard/actions";
import type { Device } from "@/lib/types";

function summary(d: Device) {
  const s = d.state;
  switch (d.type) {
    case "motion_sensor": return s.motion ? "Gerakan terdeteksi" : "Tidak ada gerakan";
    case "door_sensor": return s.open ? "Pintu terbuka" : "Pintu tertutup";
    case "temperature_sensor": return `${s.temperature_c}°C, ${s.humidity}%`;
    case "smart_switch": return s.on ? `Menyala, ${s.rated_watts ?? 0} W` : "Mati";
    case "cam": return s.recording ? "Merekam" : "Siaga";
  }
}
const Icon = { motion_sensor: Activity, door_sensor: DoorClosed, temperature_sensor: Thermometer, smart_switch: Plug, cam: Video };

export function DeviceCard({ d, room }: { d: Device; room?: string }) {
  const I = d.type === "door_sensor" && d.state.open ? DoorOpen : Icon[d.type];
  const controllable = d.is_simulated || d.is_online;
  return (
    <article className={cn("glass lit p-5", !d.is_online && !d.is_simulated && "opacity-80")}>
      <div className="flex items-start justify-between gap-3">
        <div className="grid h-11 w-11 place-items-center rounded-2xl bg-electric/[.12] text-electric"><I size={20} /></div>
        {d.type === "smart_switch" && <ToggleSwitch checked={!!d.state.on} label={`Nyalakan ${d.name}`} action={(on) => controllable ? setSwitch(d.id, on) : Promise.resolve({ ok: false, message: "Perangkat belum terhubung ke hub fisik." })} />}
        {d.type === "cam" && <ToggleSwitch checked={!!d.state.recording} label={`Rekam ${d.name}`} action={(on) => controllable ? setCamRecording(d.id, on) : Promise.resolve({ ok: false, message: "Kamera belum terhubung." })} />}
      </div>
      <h3 className="mt-4 font-medium tracking-tight">{d.name}</h3>
      <p className="text-xs text-silver/70">{deviceLabel[d.type]}{room ? `, ${room}` : ""}</p>
      <p className="mt-3 text-sm">{d.is_online || d.is_simulated ? summary(d) : "Menunggu hub fisik"}</p>
      <div className="mt-4 flex items-center justify-between text-xs text-silver/70">
        <span className="flex items-center gap-2">{d.is_simulated && <SimBadge />}<span className={`dot ${d.is_online ? "dot-ok" : ""}`} />{d.is_online ? "Online" : "Belum terhubung"}</span>
        <span>{d.last_seen ? timeAgo(d.last_seen) : "Belum pernah terlihat"}</span>
      </div>
      <div className="mt-4 border-t border-white/[.08] pt-3">
        <ActionButton action={() => deleteDevice(d.id)} confirm={`Hapus ${d.name}?`} className="inline-flex items-center gap-1.5 text-xs text-silver/70 hover:text-[#ffb3bb]" ariaLabel={`Hapus ${d.name}`}><Trash2 size={13} />Hapus</ActionButton>
      </div>
    </article>
  );
}

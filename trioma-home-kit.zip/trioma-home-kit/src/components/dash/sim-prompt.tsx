import { ActionButton } from "@/components/ui/action-form";
import { EmptyState } from "@/components/ui/bits";
import { enableSimulation } from "@/app/dashboard/actions";

export function NoDevices() {
  return (
    <EmptyState title="Belum ada perangkat"
      body="Belum ada perangkat fisik yang terhubung. Anda dapat mencoba dashboard dengan Simulation Mode: perangkat contoh akan dibuat dan setiap datanya diberi label Simulasi."
      action={<ActionButton action={enableSimulation} className="btn btn-primary">Aktifkan Simulation Mode</ActionButton>} />
  );
}

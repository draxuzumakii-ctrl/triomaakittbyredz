"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { LayoutGrid, Cpu, DoorOpen, Workflow, ShieldCheck, Zap, History, Bell, Package, Settings, Menu, X, Shield } from "lucide-react";
import { Logo } from "@/components/site/logo";
import { cn } from "@/lib/format";

const items = [
  { href: "/dashboard", label: "Beranda", Icon: LayoutGrid, exact: true },
  { href: "/dashboard/devices", label: "Perangkat", Icon: Cpu },
  { href: "/dashboard/rooms", label: "Ruangan", Icon: DoorOpen },
  { href: "/dashboard/automation", label: "Otomatisasi", Icon: Workflow },
  { href: "/dashboard/security", label: "Keamanan", Icon: ShieldCheck },
  { href: "/dashboard/energy", label: "Energi", Icon: Zap },
  { href: "/dashboard/history", label: "Riwayat", Icon: History },
  { href: "/dashboard/notifications", label: "Notifikasi", Icon: Bell },
  { href: "/dashboard/orders", label: "Pesanan", Icon: Package },
  { href: "/dashboard/settings", label: "Pengaturan", Icon: Settings },
];
const bottom = ["/dashboard", "/dashboard/devices", "/dashboard/automation", "/dashboard/notifications"];

export function DashNav({ unread, isAdmin, name }: { unread: number; isAdmin: boolean; name: string }) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const on = (i: (typeof items)[number]) => (i.exact ? path === i.href : path.startsWith(i.href));
  const badge = (i: (typeof items)[number]) => i.href.endsWith("notifications") && unread > 0 ? <span className="ml-auto rounded-full bg-electric px-1.5 text-[11px] font-semibold text-[#06101f]">{unread}</span> : null;
  return (
    <>
      {/* Desktop / tablet landscape: sidebar */}
      <aside className="glass fixed inset-y-3 left-3 z-40 hidden w-60 flex-col p-4 lg:flex">
        <div className="px-2 pb-5 pt-1"><Logo href="/dashboard" /></div>
        <nav className="flex-1 space-y-1" aria-label="Dashboard">
          {items.map((i) => (
            <Link key={i.href} href={i.href} aria-current={on(i) ? "page" : undefined}
              className={cn("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors", on(i) ? "bg-electric/15 text-white shadow-[inset_0_0_0_1px_rgba(106,159,255,.35)]" : "text-silver hover:bg-white/5 hover:text-white")}>
              <i.Icon size={17} />{i.label}{badge(i)}
            </Link>
          ))}
          {isAdmin && <Link href="/admin" className="mt-3 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-silver hover:bg-white/5 hover:text-white"><Shield size={17} />Panel admin</Link>}
        </nav>
        <p className="truncate px-2 pt-3 text-sm text-silver/80">{name || "Pengguna"}</p>
      </aside>

      {/* Mobile / tablet portrait: bilah bawah */}
      <nav className="glass fixed inset-x-3 bottom-3 z-40 flex items-center justify-around !rounded-full px-2 py-1.5 lg:hidden" aria-label="Navigasi cepat" style={{ paddingBottom: "max(.375rem, env(safe-area-inset-bottom))" }}>
        {items.filter((i) => bottom.includes(i.href)).map((i) => (
          <Link key={i.href} href={i.href} aria-label={i.label} aria-current={on(i) ? "page" : undefined}
            className={cn("relative flex min-w-[64px] flex-col items-center gap-0.5 rounded-full px-3 py-2 text-[11px]", on(i) ? "bg-electric/15 text-white" : "text-silver")}>
            <i.Icon size={19} />{i.label}
            {i.href.endsWith("notifications") && unread > 0 && <span className="absolute right-3 top-1 h-2 w-2 rounded-full bg-electric" />}
          </Link>
        ))}
        <button onClick={() => setOpen(true)} aria-label="Menu lainnya" className="flex min-w-[64px] flex-col items-center gap-0.5 px-3 py-2 text-[11px] text-silver"><Menu size={19} />Lainnya</button>
      </nav>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/60 lg:hidden" onClick={() => setOpen(false)}>
          <div className="glass w-full !rounded-b-none p-5" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Semua menu">
            <div className="mb-3 flex items-center justify-between"><p className="font-medium">{name || "Menu"}</p><button onClick={() => setOpen(false)} aria-label="Tutup"><X size={20} /></button></div>
            <div className="grid grid-cols-3 gap-2 pb-6">
              {items.map((i) => (
                <Link key={i.href} href={i.href} onClick={() => setOpen(false)} className="flex flex-col items-center gap-2 rounded-2xl bg-white/5 p-4 text-xs"><i.Icon size={20} />{i.label}</Link>
              ))}
              {isAdmin && <Link href="/admin" className="flex flex-col items-center gap-2 rounded-2xl bg-white/5 p-4 text-xs"><Shield size={20} />Admin</Link>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

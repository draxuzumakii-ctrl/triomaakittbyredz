"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useToast } from "@/components/ui/toast";

/** Berlangganan perubahan waktu nyata milik pengguna; menyegarkan data dan memunculkan toast notifikasi. */
export function RealtimeBridge({ userId }: { userId: string }) {
  const router = useRouter();
  const toast = useToast();
  useEffect(() => {
    const supabase = createClient();
    let t: ReturnType<typeof setTimeout>;
    const soon = () => { clearTimeout(t); t = setTimeout(() => router.refresh(), 400); };
    const ch = supabase.channel(`home-${userId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${userId}` }, (p) => {
        toast(p.new.level === "critical" || p.new.level === "warning" ? "error" : "info", p.new.title as string); soon();
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "devices", filter: `user_id=eq.${userId}` }, soon)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "activity_logs", filter: `user_id=eq.${userId}` }, soon)
      .subscribe();
    return () => { clearTimeout(t); supabase.removeChannel(ch); };
  }, [userId, router, toast]);
  return null;
}

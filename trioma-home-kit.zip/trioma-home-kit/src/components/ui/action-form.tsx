"use client";
import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import type { ActionResult } from "@/lib/types";
import { useToast } from "./toast";

type Action = (fd: FormData) => Promise<ActionResult | void>;

/** Form yang memanggil Server Action, menampilkan toast, dan galat per kolom. */
export function ActionForm({ action, children, className, resetOnSuccess = false, submitLabel, submitClass = "btn btn-primary", hideSubmit = false }: {
  action: Action; children: React.ReactNode; className?: string; resetOnSuccess?: boolean;
  submitLabel?: string; submitClass?: string; hideSubmit?: boolean;
}) {
  const toast = useToast();
  const router = useRouter();
  const ref = useRef<HTMLFormElement>(null);
  const [pending, start] = useTransition();
  const [errors, setErrors] = useState<Record<string, string>>({});

  return (
    <form ref={ref} className={className} noValidate
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        start(async () => {
          try {
            const res = await action(fd);
            if (!res) return;
            setErrors(res.fieldErrors ?? {});
            toast(res.ok ? "success" : "error", res.message);
            if (res.ok) { if (resetOnSuccess) ref.current?.reset(); router.refresh(); }
          } catch (err: any) {
            if (err?.digest?.startsWith?.("NEXT_REDIRECT")) throw err;
            toast("error", "Terjadi gangguan. Coba lagi sebentar lagi.");
          }
        });
      }}>
      <FormErrors.Provider value={errors}>{children}</FormErrors.Provider>
      {!hideSubmit && (
        <button type="submit" className={submitClass} disabled={pending}>
          {pending && <Loader2 size={16} className="animate-spin" />}{submitLabel ?? "Simpan"}
        </button>
      )}
    </form>
  );
}

import { createContext, useContext } from "react";
const FormErrors = createContext<Record<string, string>>({});
export function Field({ name, label, children }: { name: string; label: string; children: React.ReactNode }) {
  const err = useContext(FormErrors)[name];
  return (
    <div>
      <label className="label" htmlFor={name}>{label}</label>
      {children}
      {err && <p className="field-error" role="alert">{err}</p>}
    </div>
  );
}

/** Tombol tunggal yang memanggil Server Action (tanpa form). */
export function ActionButton({ action, children, className = "btn btn-glass btn-sm", confirm, ariaLabel }: {
  action: () => Promise<ActionResult | void>; children: React.ReactNode; className?: string; confirm?: string; ariaLabel?: string;
}) {
  const toast = useToast();
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <button type="button" className={className} disabled={pending} aria-label={ariaLabel}
      onClick={() => {
        if (confirm && !window.confirm(confirm)) return;
        start(async () => {
          try {
            const res = await action();
            if (res) toast(res.ok ? "success" : "error", res.message);
            router.refresh();
          } catch { toast("error", "Terjadi gangguan. Coba lagi sebentar lagi."); }
        });
      }}>
      {pending ? <Loader2 size={14} className="animate-spin" /> : children}
    </button>
  );
}

/** Saklar on/off dengan pembaruan optimistis. */
export function ToggleSwitch({ checked, action, label }: { checked: boolean; action: (next: boolean) => Promise<ActionResult | void>; label: string }) {
  const toast = useToast();
  const router = useRouter();
  const [value, setValue] = useState(checked);
  const [pending, start] = useTransition();
  return (
    <button type="button" role="switch" aria-checked={value} aria-label={label} className="switch" disabled={pending}
      onClick={() => {
        const next = !value; setValue(next);
        start(async () => {
          const res = await action(next);
          if (res && !res.ok) { setValue(!next); toast("error", res.message); }
          router.refresh();
        });
      }} />
  );
}

import Link from "next/link";
import { FlaskConical } from "lucide-react";
import { cn } from "@/lib/format";

export const SimBadge = ({ className }: { className?: string }) => (
  <span className={cn("sim-badge", className)} title="Data ini berasal dari Simulation Mode, bukan sensor fisik.">
    <FlaskConical size={11} /> Simulasi
  </span>
);

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} aria-hidden />;
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: React.ReactNode }) {
  return (
    <div className="solid flex flex-col items-start gap-3 p-7">
      <h3 className="text-lg font-medium tracking-tight">{title}</h3>
      <p className="prose-tight text-sm">{body}</p>
      {action}
    </div>
  );
}

export function ErrorState({ title = "Data tidak dapat dimuat", body, retryHref }: { title?: string; body: string; retryHref?: string }) {
  return (
    <div className="solid border-[rgba(255,107,122,.3)] p-7" role="alert">
      <h3 className="text-lg font-medium text-[#ffb3bb]">{title}</h3>
      <p className="prose-tight mt-1 text-sm">{body}</p>
      {retryHref && <Link href={retryHref} className="btn btn-glass btn-sm mt-4">Muat ulang</Link>}
    </div>
  );
}

export function PageHeader({ title, sub, right }: { title: string; sub?: string; right?: React.ReactNode }) {
  return (
    <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-3xl font-semibold tracking-display md:text-4xl">{title}</h1>
        {sub && <p className="mt-1.5 text-sm text-silver/80">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export function StatusPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "text-[#f6d9a6] bg-[rgba(242,180,90,.12)] border-[rgba(242,180,90,.3)]",
    confirmed: "text-[#b9d1ff] bg-[rgba(106,159,255,.14)] border-[rgba(106,159,255,.35)]",
    processing: "text-[#b9d1ff] bg-[rgba(106,159,255,.14)] border-[rgba(106,159,255,.35)]",
    completed: "text-[#a6efcb] bg-[rgba(95,211,154,.12)] border-[rgba(95,211,154,.3)]",
    cancelled: "text-[#ffb3bb] bg-[rgba(255,107,122,.12)] border-[rgba(255,107,122,.3)]",
  };
  const label: Record<string, string> = { pending: "Menunggu", confirmed: "Dikonfirmasi", processing: "Diproses", completed: "Selesai", cancelled: "Dibatalkan" };
  return <span className={cn("inline-flex rounded-full border px-2.5 py-0.5 text-xs font-medium", map[status])}>{label[status] ?? status}</span>;
}

"use client";
import Link from "next/link";
import { useRef } from "react";

/** Efek magnet terbatas (maks. 6px) pada tautan CTA utama. */
export function MagneticLink({ href, className, children }: { href: string; className?: string; children: React.ReactNode }) {
  const ref = useRef<HTMLAnchorElement>(null);
  return (
    <Link ref={ref} href={href} className={className}
      onPointerMove={(e) => {
        if (e.pointerType !== "mouse") return;
        const el = ref.current!; const r = el.getBoundingClientRect();
        const dx = ((e.clientX - r.left) / r.width - 0.5) * 12;
        const dy = ((e.clientY - r.top) / r.height - 0.5) * 8;
        el.style.transform = `translate(${dx}px, ${dy}px)`;
      }}
      onPointerLeave={() => { if (ref.current) ref.current.style.transform = ""; }}>
      {children}
    </Link>
  );
}

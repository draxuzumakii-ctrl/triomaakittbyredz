"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/format";
import { Logo } from "@/components/site/logo";

const items = [
  ["/admin", "Ikhtisar"], ["/admin/products", "Produk"], ["/admin/packages", "Paket"], ["/admin/orders", "Pesanan"],
  ["/admin/users", "Pengguna"], ["/admin/devices", "Perangkat"], ["/admin/monitoring", "Pemantauan"],
  ["/admin/announcements", "Pengumuman"], ["/admin/config", "Konfigurasi"],
];

export function AdminNav({ role }: { role: string }) {
  const path = usePathname();
  const on = (h: string) => (h === "/admin" ? path === h : path.startsWith(h));
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#080a0f]/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3">
        <Logo href="/admin" />
        <span className="rounded-full border border-electric/40 bg-electric/10 px-2.5 py-0.5 text-xs text-[#b9d1ff]">{role === "super_admin" ? "Super Admin" : "Admin"}</span>
        <Link href="/dashboard" className="ml-auto text-sm text-silver hover:text-white">Ke dashboard</Link>
      </div>
      <nav className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-3 pb-2" aria-label="Panel admin">
        {items.map(([h, l]) => <Link key={h} href={h} aria-current={on(h) ? "page" : undefined} className={cn("shrink-0 rounded-full px-3.5 py-2 text-sm", on(h) ? "bg-white/10 text-white" : "text-silver hover:text-white")}>{l}</Link>)}
      </nav>
    </header>
  );
}

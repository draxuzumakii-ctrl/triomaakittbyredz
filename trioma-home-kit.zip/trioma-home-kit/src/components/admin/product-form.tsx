import { ActionForm, Field } from "@/components/ui/action-form";
import { saveProduct } from "@/app/admin/actions";
import type { Product } from "@/lib/types";

export function ProductForm({ product, hpp }: { product?: Product; hpp?: number | null }) {
  const specs = product?.specs?.map((s) => `${s.label}: ${s.value}`).join("\n") ?? "";
  return (
    <ActionForm action={saveProduct} className="grid gap-4 md:grid-cols-2" submitLabel={product ? "Simpan perubahan" : "Tambah produk"} submitClass="btn btn-primary md:col-span-2 md:w-fit">
      {product && <input type="hidden" name="id" value={product.id} />}
      <Field name="name" label="Nama produk"><input id="name" name="name" className="field" defaultValue={product?.name} /></Field>
      <Field name="slug" label="Slug (alamat halaman)"><input id="slug" name="slug" className="field" defaultValue={product?.slug} placeholder="paket-contoh" /></Field>
      <Field name="kind" label="Jenis"><select id="kind" name="kind" className="field" defaultValue={product?.kind ?? "package"}><option value="package">Paket</option><option value="accessory">Aksesori</option></select></Field>
      <Field name="focus" label="Fokus"><input id="focus" name="focus" className="field" defaultValue={product?.focus} /></Field>
      <Field name="price_idr" label="Harga jual (Rp)"><input id="price_idr" name="price_idr" type="number" min={0} className="field" defaultValue={product?.price_idr} /></Field>
      <Field name="hpp_idr" label="HPP (Rp, hanya terlihat admin)"><input id="hpp_idr" name="hpp_idr" type="number" min={0} className="field" defaultValue={hpp ?? ""} /></Field>
      <Field name="stock" label="Stok"><input id="stock" name="stock" type="number" min={0} className="field" defaultValue={product?.stock ?? 0} /></Field>
      <Field name="image" label="Foto produk (JPG/PNG/WebP, maks. 4 MB)"><input id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp" className="field" /></Field>
      <div className="md:col-span-2"><Field name="tagline" label="Tagline"><input id="tagline" name="tagline" className="field" defaultValue={product?.tagline} /></Field></div>
      <div className="md:col-span-2"><Field name="description" label="Deskripsi"><textarea id="description" name="description" className="field" defaultValue={product?.description} /></Field></div>
      <div className="md:col-span-2"><Field name="specs" label="Spesifikasi teknis (satu baris per item, format Label: Nilai)"><textarea id="specs" name="specs" className="field" defaultValue={specs} /></Field></div>
      <label className="flex items-center gap-3 text-sm md:col-span-2"><input type="checkbox" name="is_active" defaultChecked={product?.is_active ?? true} className="h-4 w-4 accent-[#6A9FFF]" />Tampilkan di website</label>
    </ActionForm>
  );
}

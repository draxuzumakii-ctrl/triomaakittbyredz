"use client";
import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "@/components/ui/toast";
import { setUserRole } from "@/app/admin/actions";

export function RoleSelect({ id, role, disabled }: { id: string; role: string; disabled?: boolean }) {
  const toast = useToast(); const router = useRouter(); const [pending, start] = useTransition();
  return (
    <select className="field !min-h-[36px] !w-auto !py-1 text-sm" value={role} disabled={disabled || pending} aria-label="Ubah role"
      onChange={(e) => start(async () => { const r = await setUserRole(id, e.target.value); toast(r.ok ? "success" : "error", r.message); router.refresh(); })}>
      <option value="user">User</option><option value="admin">Admin</option><option value="super_admin">Super Admin</option>
    </select>
  );
}

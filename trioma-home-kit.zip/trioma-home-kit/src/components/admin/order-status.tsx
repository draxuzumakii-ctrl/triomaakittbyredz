"use client";
import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "@/components/ui/toast";
import { setOrderStatus } from "@/app/admin/actions";

export function OrderStatusSelect({ id, status }: { id: string; status: string }) {
  const toast = useToast(); const router = useRouter(); const [pending, start] = useTransition();
  return (
    <select className="field !min-h-[36px] !w-auto !py-1 text-sm" value={status} disabled={pending} aria-label="Ubah status pesanan"
      onChange={(e) => start(async () => { const r = await setOrderStatus(id, e.target.value); toast(r.ok ? "success" : "error", r.message); router.refresh(); })}>
      <option value="pending">Menunggu</option><option value="confirmed">Dikonfirmasi</option><option value="processing">Diproses</option><option value="completed">Selesai</option><option value="cancelled">Dibatalkan</option>
    </select>
  );
}

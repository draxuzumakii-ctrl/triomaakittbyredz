import { z } from "zod";
import type { ActionResult } from "@/lib/types";

const phone = z.string().trim().regex(/^[0-9+][0-9 -]{6,18}$/, "Nomor telepon tidak valid.");

export const registerSchema = z.object({
  full_name: z.string().trim().min(2, "Nama minimal 2 karakter.").max(120),
  email: z.string().trim().email("Email tidak valid."),
  phone: phone.optional().or(z.literal("")),
  password: z.string().min(8, "Kata sandi minimal 8 karakter.").max(72),
});
export const loginSchema = z.object({
  email: z.string().trim().email("Email tidak valid."),
  password: z.string().min(1, "Isi kata sandi."),
});
export const orderSchema = z.object({
  product_id: z.string().uuid(),
  quantity: z.coerce.number().int().min(1, "Minimal 1.").max(50, "Maksimal 50."),
  customer_name: z.string().trim().min(2, "Isi nama penerima.").max(120),
  phone,
  address: z.string().trim().min(8, "Alamat terlalu pendek.").max(500),
  notes: z.string().trim().max(500).optional().default(""),
});
export const contactSchema = z.object({
  name: z.string().trim().min(2, "Isi nama Anda.").max(120),
  email: z.string().trim().email("Email tidak valid."),
  message: z.string().trim().min(10, "Pesan minimal 10 karakter.").max(2000),
});
export const productSchema = z.object({
  name: z.string().trim().min(2).max(120),
  slug: z.string().trim().regex(/^[a-z0-9-]+$/, "Slug hanya huruf kecil, angka, dan tanda hubung."),
  kind: z.enum(["package", "accessory"]),
  focus: z.string().trim().max(120).default(""),
  tagline: z.string().trim().max(200).default(""),
  description: z.string().trim().max(3000).default(""),
  price_idr: z.coerce.number().int().min(0),
  stock: z.coerce.number().int().min(0),
  hpp_idr: z.coerce.number().int().min(0).optional(),
  specs: z.string().default(""), // satu baris: "Label: Nilai"
  is_active: z.coerce.boolean().default(false),
});
export const deviceSchema = z.object({
  name: z.string().trim().min(1, "Isi nama perangkat.").max(80),
  type: z.enum(["motion_sensor", "door_sensor", "temperature_sensor", "smart_switch", "cam"]),
  room_id: z.string().uuid().optional().or(z.literal("")),
  is_simulated: z.enum(["true", "false"]),
});
export const automationSchema = z.object({
  name: z.string().trim().min(1, "Isi nama otomatisasi.").max(80),
  trigger_type: z.enum(["manual", "motion", "door_open", "temperature_above"]),
  trigger_value: z.coerce.number().optional(),
  action_type: z.enum(["switches_off", "switches_on", "notify", "arm_security", "disarm_security"]),
});

/** Ubah ZodError menjadi ActionResult yang ramah pengguna. */
export function zodFail(err: z.ZodError): ActionResult {
  const fieldErrors: Record<string, string> = {};
  for (const i of err.issues) fieldErrors[String(i.path[0])] ??= i.message;
  return { ok: false, message: err.issues[0]?.message ?? "Data tidak valid.", fieldErrors };
}

export function parseSpecs(text: string) {
  return text.split("\n").map((l) => l.trim()).filter(Boolean).map((l) => {
    const i = l.indexOf(":");
    return i === -1 ? { label: l, value: "" } : { label: l.slice(0, i).trim(), value: l.slice(i + 1).trim() };
  });
}

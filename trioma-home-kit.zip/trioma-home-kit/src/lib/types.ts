export type Role = "user" | "admin" | "super_admin";
export type OrderStatus = "pending" | "confirmed" | "processing" | "completed" | "cancelled";
export type DeviceType = "motion_sensor" | "door_sensor" | "temperature_sensor" | "smart_switch" | "cam";

export type Profile = {
  id: string; full_name: string; phone: string | null; role: Role;
  security_armed: boolean; home_mode: "pergi" | "pulang"; created_at: string;
};
export type Product = {
  id: string; slug: string; name: string; kind: "package" | "accessory"; focus: string;
  tagline: string; description: string; price_idr: number; stock: number;
  image_url: string | null; specs: { label: string; value: string }[]; is_active: boolean; sort_order: number;
};
export type PackageItem = { id: string; product_id: string; item_name: string; quantity: number; notes: string; sort_order: number };
export type Room = { id: string; name: string };
export type Device = {
  id: string; room_id: string | null; name: string; type: DeviceType; is_simulated: boolean;
  is_online: boolean; state: Record<string, any>; last_seen: string | null;
};
export type Automation = {
  id: string; name: string; kind: "pergi" | "pulang" | "custom"; trigger_type: string;
  trigger_value: number | null; action_type: string; is_enabled: boolean; last_run_at: string | null;
};
export type ActivityLog = { id: string; category: string; message: string; source: "device" | "simulation" | "user" | "system"; created_at: string; device_id: string | null };
export type Notification = { id: string; title: string; body: string; level: "info" | "success" | "warning" | "critical"; is_read: boolean; created_at: string };
export type Order = {
  id: string; code: string; user_id: string; customer_name: string; phone: string; address: string; notes: string;
  status: OrderStatus; total_idr: number; created_at: string;
};
export type ActionResult = { ok: boolean; message: string; fieldErrors?: Record<string, string> };

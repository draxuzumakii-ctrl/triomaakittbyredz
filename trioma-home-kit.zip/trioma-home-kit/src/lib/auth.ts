import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Profile } from "@/lib/types";

export async function getSessionProfile() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { supabase, user: null, profile: null as Profile | null };
  const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single();
  return { supabase, user, profile: (data as Profile | null) };
}

export async function requireUser() {
  const s = await getSessionProfile();
  if (!s.user || !s.profile) redirect("/auth/login");
  return { supabase: s.supabase, user: s.user, profile: s.profile as Profile };
}

export async function requireAdmin() {
  const s = await requireUser();
  if (s.profile.role === "user") redirect("/dashboard");
  return s;
}

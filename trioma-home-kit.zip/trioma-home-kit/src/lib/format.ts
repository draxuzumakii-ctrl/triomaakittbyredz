export const rupiah = (n: number) =>
  new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);

export const dateTime = (iso: string) =>
  new Intl.DateTimeFormat("id-ID", { dateStyle: "medium", timeStyle: "short" }).format(new Date(iso));

export function timeAgo(iso: string) {
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return "baru saja";
  if (s < 3600) return `${Math.floor(s / 60)} menit lalu`;
  if (s < 86400) return `${Math.floor(s / 3600)} jam lalu`;
  return `${Math.floor(s / 86400)} hari lalu`;
}

export const statusLabel: Record<string, string> = {
  pending: "Menunggu", confirmed: "Dikonfirmasi", processing: "Diproses",
  completed: "Selesai", cancelled: "Dibatalkan",
};
export const deviceLabel: Record<string, string> = {
  motion_sensor: "Sensor Gerak", door_sensor: "Sensor Pintu", temperature_sensor: "Sensor Suhu",
  smart_switch: "Smart Switch", cam: "TRIOMA Cam",
};
export const cn = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(" ");

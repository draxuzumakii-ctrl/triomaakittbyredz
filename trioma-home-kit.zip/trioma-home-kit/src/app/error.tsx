"use client";
export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="grid min-h-dvh place-items-center px-6">
      <div className="max-w-md">
        <h1 className="display text-5xl">Ada yang tidak berjalan</h1>
        <p className="prose-tight mt-4">Halaman gagal dimuat. Periksa koneksi Anda lalu coba lagi.</p>
        <button onClick={reset} className="btn btn-primary mt-7">Coba lagi</button>
      </div>
    </main>
  );
}

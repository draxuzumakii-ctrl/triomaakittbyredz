import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { EmptyState, PageHeader } from "@/components/ui/bits";
import { ActionButton, ActionForm, Field } from "@/components/ui/action-form";
import { setStock, toggleProduct } from "../actions";
import { rupiah } from "@/lib/format";
import type { Product } from "@/lib/types";
export const metadata = { title: "Produk" };

export default async function AdminProducts() {
  const { supabase } = await requireAdmin();
  const [{ data }, { data: costs }] = await Promise.all([supabase.from("products").select("*").order("sort_order"), supabase.from("product_costs").select("*")]);
  const products = (data ?? []) as Product[];
  const hpp = new Map((costs ?? []).map((c: any) => [c.product_id, c.hpp_idr as number]));
  return (
    <>
      <PageHeader title="Manajemen produk" right={<Link href="/admin/products/new" className="btn btn-primary btn-sm">Tambah produk</Link>} />
      {products.length === 0 ? <EmptyState title="Belum ada produk" body="Tambahkan produk pertama Anda." /> : (
        <div className="glass overflow-x-auto"><table className="data">
          <thead><tr><th>Produk</th><th>Harga</th><th>HPP</th><th>Margin</th><th>Stok</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>{products.map((p) => {
            const h = hpp.get(p.id);
            return (
              <tr key={p.id}>
                <td><p className="font-medium">{p.name}</p><p className="text-xs text-silver/60">{p.kind === "package" ? "Paket" : "Aksesori"}</p></td>
                <td>{rupiah(p.price_idr)}</td><td>{h != null ? rupiah(h) : "-"}</td><td>{h != null ? rupiah(p.price_idr - h) : "-"}</td>
                <td><ActionForm action={setStock} className="flex items-center gap-2" submitLabel="Set" submitClass="btn btn-glass btn-sm"><input type="hidden" name="id" value={p.id} /><input name="stock" type="number" min={0} defaultValue={p.stock} className="field !min-h-[36px] !w-20 !px-2" aria-label={`Stok ${p.name}`} /></ActionForm></td>
                <td><ActionButton action={toggleProduct.bind(null, p.id, !p.is_active)} className={`btn btn-sm ${p.is_active ? "btn-glass" : "btn-danger"}`}>{p.is_active ? "Aktif" : "Disembunyikan"}</ActionButton></td>
                <td><Link href={`/admin/products/edit/${p.id}`} className="btn btn-glass btn-sm">Edit</Link></td>
              </tr>
            );
          })}</tbody></table></div>
      )}
    </>
  );
}

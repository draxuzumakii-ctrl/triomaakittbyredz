import { requireAdmin } from "@/lib/auth";
import { PageHeader } from "@/components/ui/bits";
import { ProductForm } from "@/components/admin/product-form";
export const metadata = { title: "Tambah produk" };

export default async function NewProduct() {
  await requireAdmin();
  return (<><PageHeader title="Tambah produk" /><div className="glass p-6"><ProductForm /></div></>);
}

import { notFound } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { PageHeader } from "@/components/ui/bits";
import { ProductForm } from "@/components/admin/product-form";
import type { Product } from "@/lib/types";
export const metadata = { title: "Edit produk" };

export default async function EditProduct({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("products").select("*").eq("id", id).maybeSingle();
  if (!data) notFound();
  const { data: cost } = await supabase.from("product_costs").select("hpp_idr").eq("product_id", id).maybeSingle();
  return (<><PageHeader title={`Edit ${data.name}`} /><div className="glass p-6"><ProductForm product={data as Product} hpp={cost?.hpp_idr} /></div></>);
}

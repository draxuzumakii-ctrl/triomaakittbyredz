"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { parseSpecs, productSchema, zodFail } from "@/lib/validation";
import type { ActionResult } from "@/lib/types";

const bump = () => { revalidatePath("/admin", "layout"); revalidatePath("/products", "layout"); revalidatePath("/"); };
const ALLOWED = ["image/jpeg", "image/png", "image/webp"];

async function adminLog(c: Awaited<ReturnType<typeof requireAdmin>>, message: string) {
  await c.supabase.from("activity_logs").insert({ user_id: null, category: "admin", message: `${c.profile.full_name || "Admin"}: ${message}`, source: "user" });
}

export async function saveProduct(fd: FormData): Promise<ActionResult | void> {
  const c = await requireAdmin();
  const raw: Record<string, any> = Object.fromEntries(fd);
  if (raw.hpp_idr === "") delete raw.hpp_idr;
  const p = productSchema.safeParse(raw);
  if (!p.success) return zodFail(p.error);
  const { hpp_idr, specs, ...rest } = p.data;
  const id = typeof raw.id === "string" && raw.id ? raw.id : null;

  let image_url: string | undefined;
  const file = fd.get("image");
  if (file instanceof File && file.size > 0) {
    if (!ALLOWED.includes(file.type)) return { ok: false, message: "Foto harus berformat JPG, PNG, atau WebP.", fieldErrors: { image: "Format tidak didukung." } };
    if (file.size > 4 * 1024 * 1024) return { ok: false, message: "Ukuran foto maksimal 4 MB.", fieldErrors: { image: "Terlalu besar." } };
    const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
    const path = `${rest.slug}-${Date.now()}.${ext}`;
    const { error: upErr } = await c.supabase.storage.from("product-images").upload(path, file, { contentType: file.type, upsert: false });
    if (upErr) return { ok: false, message: "Foto gagal diunggah. Pastikan bucket product-images sudah dibuat." };
    image_url = c.supabase.storage.from("product-images").getPublicUrl(path).data.publicUrl;
  }

  const row = { ...rest, specs: parseSpecs(specs), ...(image_url ? { image_url } : {}), updated_at: new Date().toISOString() };
  let productId = id;
  if (id) {
    const { error } = await c.supabase.from("products").update(row).eq("id", id);
    if (error) return { ok: false, message: error.code === "23505" ? "Slug sudah dipakai produk lain." : "Produk gagal disimpan." };
  } else {
    const { data, error } = await c.supabase.from("products").insert(row).select("id").single();
    if (error || !data) return { ok: false, message: error?.code === "23505" ? "Slug sudah dipakai produk lain." : "Produk gagal dibuat." };
    productId = data.id;
  }
  if (hpp_idr != null && productId) await c.supabase.from("product_costs").upsert({ product_id: productId, hpp_idr });
  await adminLog(c, `${id ? "mengubah" : "menambah"} produk ${rest.name}.`);
  bump();
  if (!id) redirect("/admin/products");
  return { ok: true, message: "Produk disimpan." };
}

export async function toggleProduct(id: string, active: boolean): Promise<ActionResult> {
  const c = await requireAdmin();
  const { error } = await c.supabase.from("products").update({ is_active: active }).eq("id", id);
  if (error) return { ok: false, message: "Gagal mengubah status produk." };
  await adminLog(c, `${active ? "mengaktifkan" : "menonaktifkan"} produk.`); bump();
  return { ok: true, message: active ? "Produk ditampilkan." : "Produk disembunyikan." };
}

export async function setStock(fd: FormData): Promise<ActionResult> {
  const c = await requireAdmin();
  const p = z.object({ id: z.string().uuid(), stock: z.coerce.number().int().min(0, "Stok tidak boleh negatif.") }).safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  await c.supabase.from("products").update({ stock: p.data.stock }).eq("id", p.data.id); bump();
  return { ok: true, message: "Stok diperbarui." };
}

export async function addPackageItem(fd: FormData): Promise<ActionResult> {
  const c = await requireAdmin();
  const p = z.object({ product_id: z.string().uuid(), item_name: z.string().trim().min(1, "Isi nama item.").max(120), quantity: z.coerce.number().int().min(1).max(99), notes: z.string().trim().max(200).default("") }).safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  const { error } = await c.supabase.from("product_packages").insert(p.data);
  if (error) return { ok: false, message: "Item gagal ditambahkan." };
  bump(); return { ok: true, message: "Item ditambahkan ke paket." };
}
export async function deletePackageItem(id: string): Promise<ActionResult> {
  const c = await requireAdmin();
  await c.supabase.from("product_packages").delete().eq("id", id); bump();
  return { ok: true, message: "Item dihapus dari paket." };
}

export async function setOrderStatus(id: string, status: string): Promise<ActionResult> {
  const c = await requireAdmin();
  const s = z.enum(["pending", "confirmed", "processing", "completed", "cancelled"]).safeParse(status);
  if (!s.success) return { ok: false, message: "Status tidak valid." };
  const { error } = await c.supabase.from("orders").update({ status: s.data }).eq("id", id);
  if (error) return { ok: false, message: "Status gagal diperbarui." };
  await adminLog(c, `mengubah status pesanan menjadi ${s.data}.`); bump();
  return { ok: true, message: "Status pesanan diperbarui. Pengguna diberi tahu." };
}

export async function setUserRole(userId: string, role: string): Promise<ActionResult> {
  const c = await requireAdmin();
  if (c.profile.role !== "super_admin") return { ok: false, message: "Hanya Super Admin yang dapat mengubah role." };
  const r = z.enum(["user", "admin", "super_admin"]).safeParse(role);
  if (!r.success) return { ok: false, message: "Role tidak valid." };
  if (userId === c.user.id) return { ok: false, message: "Anda tidak dapat mengubah role akun sendiri." };
  const { error } = await c.supabase.from("profiles").update({ role: r.data }).eq("id", userId);
  if (error) return { ok: false, message: "Role gagal diubah." };
  await adminLog(c, `mengubah role pengguna menjadi ${r.data}.`); bump();
  return { ok: true, message: "Role diperbarui." };
}

export async function adminDeleteDevice(id: string): Promise<ActionResult> {
  const c = await requireAdmin();
  const { error } = await c.supabase.from("devices").delete().eq("id", id);
  if (error) return { ok: false, message: "Perangkat gagal dihapus." };
  await adminLog(c, "menghapus sebuah perangkat pengguna."); bump();
  return { ok: true, message: "Perangkat dihapus." };
}

export async function saveAnnouncement(fd: FormData): Promise<ActionResult> {
  const c = await requireAdmin();
  const p = z.object({ text: z.string().trim().max(240, "Maksimal 240 karakter."), active: z.coerce.boolean().default(false) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  if (p.data.active && !p.data.text) return { ok: false, message: "Isi teks pengumuman sebelum menampilkannya.", fieldErrors: { text: "Wajib diisi." } };
  await c.supabase.from("system_settings").upsert({ key: "announcement", value: p.data, updated_at: new Date().toISOString() });
  bump(); return { ok: true, message: p.data.active ? "Pengumuman ditampilkan." : "Pengumuman disimpan (tidak ditampilkan)." };
}

export async function saveSiteConfig(fd: FormData): Promise<ActionResult> {
  const c = await requireAdmin();
  const p = z.object({
    store_name: z.string().trim().min(2).max(80),
    whatsapp_number: z.string().trim().regex(/^(\+?[0-9]{8,16})?$/, "Gunakan angka saja, contoh 6281234567890.").default(""),
    contact_email: z.string().trim().email("Email tidak valid.").or(z.literal("")).default(""),
    contact_address: z.string().trim().max(300).default(""),
  }).safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  await c.supabase.from("system_settings").upsert({ key: "site", value: p.data, updated_at: new Date().toISOString() });
  bump(); return { ok: true, message: "Konfigurasi website disimpan." };
}

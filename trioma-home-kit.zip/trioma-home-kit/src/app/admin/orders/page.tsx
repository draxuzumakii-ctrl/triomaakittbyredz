import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { EmptyState, PageHeader } from "@/components/ui/bits";
import { OrderStatusSelect } from "@/components/admin/order-status";
import { dateTime, rupiah, cn } from "@/lib/format";
export const metadata = { title: "Pesanan" };

const tabs = [["", "Semua"], ["pending", "Menunggu"], ["confirmed", "Dikonfirmasi"], ["processing", "Diproses"], ["completed", "Selesai"], ["cancelled", "Dibatalkan"]];

export default async function AdminOrders({ searchParams }: { searchParams: Promise<{ s?: string }> }) {
  const { s = "" } = await searchParams;
  const { supabase } = await requireAdmin();
  let q = supabase.from("orders").select("*, order_items(quantity, products(name))").order("created_at", { ascending: false }).limit(200);
  if (tabs.some(([v]) => v && v === s)) q = q.eq("status", s);
  const { data } = await q;
  const orders = (data ?? []) as any[];
  return (
    <>
      <PageHeader title="Pesanan" />
      <div className="mb-5 flex flex-wrap gap-2">{tabs.map(([v, l]) => <Link key={v} href={v ? `?s=${v}` : "?"} className={cn("btn btn-sm", s === v ? "btn-primary" : "btn-glass")}>{l}</Link>)}</div>
      {orders.length === 0 ? <EmptyState title="Tidak ada pesanan" body="Belum ada pesanan dengan status ini." /> : (
        <div className="glass overflow-x-auto"><table className="data">
          <thead><tr><th>Kode</th><th>Pemesan</th><th>Item</th><th>Total</th><th>Waktu</th><th>Status</th></tr></thead>
          <tbody>{orders.map((o) => (
            <tr key={o.id}>
              <td className="font-mono">{o.code}</td>
              <td><p>{o.customer_name}</p><p className="text-xs text-silver/60">{o.phone}</p><p className="max-w-[220px] truncate text-xs text-silver/60" title={o.address}>{o.address}</p>{o.notes && <p className="text-xs text-silver/60">Catatan: {o.notes}</p>}</td>
              <td>{o.order_items.map((i: any) => `${i.products?.name ?? "Produk"} x${i.quantity}`).join(", ")}</td>
              <td>{rupiah(o.total_idr)}</td><td className="text-silver/70">{dateTime(o.created_at)}</td>
              <td><OrderStatusSelect id={o.id} status={o.status} /></td>
            </tr>))}</tbody></table></div>
      )}
    </>
  );
}

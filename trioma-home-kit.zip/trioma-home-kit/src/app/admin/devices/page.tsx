import { requireAdmin } from "@/lib/auth";
import { EmptyState, PageHeader, SimBadge } from "@/components/ui/bits";
import { ActionButton } from "@/components/ui/action-form";
import { adminDeleteDevice } from "../actions";
import { deviceLabel, timeAgo } from "@/lib/format";
export const metadata = { title: "Perangkat" };

export default async function AdminDevices() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("devices").select("*, profiles(full_name)").order("created_at", { ascending: false }).limit(300);
  const devices = (data ?? []) as any[];
  const sim = devices.filter((d) => d.is_simulated).length;
  return (
    <>
      <PageHeader title="Perangkat pengguna" sub={`${devices.length} terdaftar: ${devices.length - sim} fisik, ${sim} simulasi.`} />
      {devices.length === 0 ? <EmptyState title="Belum ada perangkat" body="Perangkat yang ditambahkan pengguna akan tampil di sini." /> : (
        <div className="glass overflow-x-auto"><table className="data">
          <thead><tr><th>Perangkat</th><th>Pemilik</th><th>Jenis</th><th>Status</th><th>Terakhir terlihat</th><th /></tr></thead>
          <tbody>{devices.map((d) => (
            <tr key={d.id}>
              <td><span className="flex items-center gap-2">{d.name}{d.is_simulated && <SimBadge />}</span></td>
              <td>{d.profiles?.full_name || "-"}</td><td>{deviceLabel[d.type]}</td>
              <td><span className="flex items-center gap-2"><span className={`dot ${d.is_online ? "dot-ok" : ""}`} />{d.is_online ? "Online" : "Belum terhubung"}</span></td>
              <td className="text-silver/70">{d.last_seen ? timeAgo(d.last_seen) : "-"}</td>
              <td><ActionButton action={adminDeleteDevice.bind(null, d.id)} confirm={`Hapus ${d.name}?`} className="btn btn-danger btn-sm">Hapus</ActionButton></td>
            </tr>))}</tbody></table></div>
      )}
    </>
  );
}

import { requireAdmin } from "@/lib/auth";
import { PageHeader } from "@/components/ui/bits";
import { ActionButton, ActionForm, Field } from "@/components/ui/action-form";
import { addPackageItem, deletePackageItem } from "../actions";
import type { PackageItem, Product } from "@/lib/types";
export const metadata = { title: "Paket" };

export default async function AdminPackages() {
  const { supabase } = await requireAdmin();
  const [{ data: p }, { data: i }] = await Promise.all([supabase.from("products").select("id,name,kind").order("sort_order"), supabase.from("product_packages").select("*").order("sort_order")]);
  const products = (p ?? []) as Pick<Product, "id" | "name" | "kind">[]; const items = (i ?? []) as PackageItem[];
  return (
    <>
      <PageHeader title="Isi paket" sub="Atur komponen yang ada di setiap produk." />
      <div className="grid gap-4 md:grid-cols-2">
        {products.map((pr) => (
          <section key={pr.id} className="glass p-5">
            <h2 className="font-medium">{pr.name}</h2>
            <ul className="mt-3 divide-y divide-white/[.08] text-sm">
              {items.filter((x) => x.product_id === pr.id).map((x) => (
                <li key={x.id} className="flex items-center justify-between py-2"><span>{x.item_name} x{x.quantity}{x.notes && <span className="text-silver/60"> ({x.notes})</span>}</span><ActionButton action={deletePackageItem.bind(null, x.id)} ariaLabel={`Hapus ${x.item_name}`}>Hapus</ActionButton></li>
              ))}
              {items.filter((x) => x.product_id === pr.id).length === 0 && <li className="py-2 text-silver/70">Belum ada isi paket.</li>}
            </ul>
            <ActionForm action={addPackageItem} resetOnSuccess className="mt-4 grid grid-cols-[1fr_70px] gap-2" submitLabel="Tambah item" submitClass="btn btn-glass btn-sm col-span-2 w-fit">
              <input type="hidden" name="product_id" value={pr.id} />
              <Field name="item_name" label="Item"><input name="item_name" className="field !min-h-[38px]" placeholder="Sensor Gerak" /></Field>
              <Field name="quantity" label="Jumlah"><input name="quantity" type="number" min={1} defaultValue={1} className="field !min-h-[38px]" /></Field>
            </ActionForm>
          </section>
        ))}
      </div>
    </>
  );
}

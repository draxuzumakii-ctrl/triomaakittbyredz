import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { PageHeader, StatusPill, EmptyState } from "@/components/ui/bits";
import { dateTime, rupiah } from "@/lib/format";
import type { Order } from "@/lib/types";
export const metadata = { title: "Ikhtisar" };

export default async function AdminOverview() {
  const { supabase } = await requireAdmin();
  const count = async (t: string, f?: (q: any) => any) => { let q = supabase.from(t).select("id", { count: "exact", head: true }); if (f) q = f(q); return (await q).count ?? 0; };
  const [users, devices, pending, orders, { data: done }, { data: low }, { data: recent }] = await Promise.all([
    count("profiles"), count("devices"), count("orders", (q) => q.eq("status", "pending")), count("orders"),
    supabase.from("orders").select("total_idr").eq("status", "completed"),
    supabase.from("products").select("id,name,stock").lte("stock", 5).eq("is_active", true),
    supabase.from("orders").select("*").order("created_at", { ascending: false }).limit(6),
  ]);
  const revenue = (done ?? []).reduce((s, o: any) => s + o.total_idr, 0);
  const stats = [["Pesanan menunggu", pending], ["Total pesanan", orders], ["Pendapatan (selesai)", rupiah(revenue)], ["Pengguna", users], ["Perangkat terdaftar", devices]];
  return (
    <>
      <PageHeader title="Ikhtisar" sub="Semua angka diambil langsung dari database." />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {stats.map(([l, v]) => <div key={l as string} className="glass p-4"><p className="text-xl font-semibold tracking-tight">{v}</p><p className="mt-1 text-xs text-silver/80">{l}</p></div>)}
      </div>
      {(low ?? []).length > 0 && (
        <section className="solid mt-5 border-[rgba(242,180,90,.3)] p-5"><h2 className="font-medium text-[#f6d9a6]">Stok menipis</h2>
          <ul className="mt-2 text-sm text-silver">{(low ?? []).map((p: any) => <li key={p.id}>{p.name}: sisa {p.stock}</li>)}</ul></section>
      )}
      <h2 className="mb-3 mt-8 text-lg font-medium">Pesanan terbaru</h2>
      {(recent ?? []).length === 0 ? <EmptyState title="Belum ada pesanan" body="Pesanan pelanggan akan muncul di sini." /> : (
        <div className="glass overflow-x-auto"><table className="data"><thead><tr><th>Kode</th><th>Pemesan</th><th>Total</th><th>Status</th><th>Waktu</th></tr></thead>
          <tbody>{(recent as Order[]).map((o) => <tr key={o.id}><td className="font-mono">{o.code}</td><td>{o.customer_name}</td><td>{rupiah(o.total_idr)}</td><td><StatusPill status={o.status} /></td><td className="text-silver/70">{dateTime(o.created_at)}</td></tr>)}</tbody></table></div>
      )}
      <Link href="/admin/orders" className="btn btn-glass btn-sm mt-4">Kelola pesanan</Link>
    </>
  );
}

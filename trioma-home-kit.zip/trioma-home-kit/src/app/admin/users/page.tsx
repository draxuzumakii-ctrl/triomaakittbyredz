import { requireAdmin } from "@/lib/auth";
import { PageHeader } from "@/components/ui/bits";
import { RoleSelect } from "@/components/admin/role-select";
import { dateTime } from "@/lib/format";
import type { Profile } from "@/lib/types";
export const metadata = { title: "Pengguna" };

export default async function AdminUsers() {
  const { supabase, profile, user } = await requireAdmin();
  const { data } = await supabase.from("profiles").select("*").order("created_at", { ascending: false }).limit(300);
  const users = (data ?? []) as Profile[];
  const canEdit = profile.role === "super_admin";
  return (
    <>
      <PageHeader title="Pengguna" sub={canEdit ? "Sebagai Super Admin, Anda dapat mengubah role." : "Hanya Super Admin yang dapat mengubah role."} />
      <div className="glass overflow-x-auto"><table className="data">
        <thead><tr><th>Nama</th><th>Telepon</th><th>Bergabung</th><th>Role</th></tr></thead>
        <tbody>{users.map((u) => <tr key={u.id}><td>{u.full_name || "(tanpa nama)"}</td><td className="text-silver/70">{u.phone ?? "-"}</td><td className="text-silver/70">{dateTime(u.created_at)}</td><td><RoleSelect id={u.id} role={u.role} disabled={!canEdit || u.id === user.id} /></td></tr>)}</tbody></table></div>
    </>
  );
}

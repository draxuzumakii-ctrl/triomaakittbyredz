import { requireAdmin } from "@/lib/auth";
import { PageHeader, SimBadge } from "@/components/ui/bits";
import { dateTime } from "@/lib/format";
export const metadata = { title: "Pemantauan sistem" };

export default async function Monitoring() {
  const { supabase } = await requireAdmin();
  const since = new Date(Date.now() - 86400000).toISOString();
  const cnt = async (f: (q: any) => any) => (await f(supabase.from("activity_logs").select("id", { count: "exact", head: true }))).count ?? 0;
  const [all24, sim24, dev24, { count: online }, { count: physical }, { data: logs }] = await Promise.all([
    cnt((q) => q.gte("created_at", since)), cnt((q) => q.gte("created_at", since).eq("source", "simulation")), cnt((q) => q.gte("created_at", since).eq("source", "device")),
    supabase.from("devices").select("id", { count: "exact", head: true }).eq("is_online", true).eq("is_simulated", false),
    supabase.from("devices").select("id", { count: "exact", head: true }).eq("is_simulated", false),
    supabase.from("activity_logs").select("*, profiles(full_name)").order("created_at", { ascending: false }).limit(40),
  ]);
  const stats = [["Aktivitas 24 jam", all24], ["Dari simulasi", sim24], ["Dari perangkat fisik", dev24], ["Perangkat fisik online", `${online ?? 0} / ${physical ?? 0}`]];
  return (
    <>
      <PageHeader title="Pemantauan sistem" sub="Aktivitas lintas pengguna dari database." />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{stats.map(([l, v]) => <div key={l as string} className="glass p-4"><p className="text-xl font-semibold">{v}</p><p className="mt-1 text-xs text-silver/80">{l}</p></div>)}</div>
      <p className="solid mt-4 px-4 py-3 text-sm text-silver">Integrasi hub ESP32-S3 dan Zigbee belum aktif. Angka &quot;perangkat fisik&quot; akan terisi setelah firmware mengirim data ke platform.</p>
      <div className="glass mt-5 overflow-x-auto"><table className="data"><thead><tr><th>Waktu</th><th>Pengguna</th><th>Kategori</th><th>Aktivitas</th></tr></thead>
        <tbody>{((logs ?? []) as any[]).map((l) => <tr key={l.id}><td className="whitespace-nowrap text-silver/70">{dateTime(l.created_at)}</td><td>{l.profiles?.full_name || "Sistem"}</td><td>{l.category}</td><td><span className="flex items-center gap-2">{l.message}{l.source === "simulation" && <SimBadge />}</span></td></tr>)}</tbody></table></div>
    </>
  );
}

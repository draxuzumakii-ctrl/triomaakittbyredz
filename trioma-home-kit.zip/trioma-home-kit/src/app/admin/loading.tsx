import { Skeleton } from "@/components/ui/bits";
export default function Loading() {
  return (<div className="space-y-4" aria-busy="true"><Skeleton className="h-9 w-56" /><div className="grid grid-cols-2 gap-3 md:grid-cols-4">{[0,1,2,3].map((i) => <Skeleton key={i} className="h-24" />)}</div><Skeleton className="h-72" /></div>);
}

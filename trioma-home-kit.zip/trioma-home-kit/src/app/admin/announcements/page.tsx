import { requireAdmin } from "@/lib/auth";
import { PageHeader } from "@/components/ui/bits";
import { ActionForm, Field } from "@/components/ui/action-form";
import { saveAnnouncement } from "../actions";
export const metadata = { title: "Pengumuman" };

export default async function Announcements() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("system_settings").select("value").eq("key", "announcement").maybeSingle();
  const v = (data?.value ?? {}) as { active?: boolean; text?: string };
  return (
    <>
      <PageHeader title="Pengumuman" sub="Tampil sebagai bilah di bagian atas website publik." />
      <div className="glass max-w-xl p-6">
        <ActionForm action={saveAnnouncement} className="space-y-4" submitLabel="Simpan pengumuman">
          <Field name="text" label="Teks pengumuman (maks. 240 karakter)"><textarea id="text" name="text" className="field" defaultValue={v.text ?? ""} maxLength={240} /></Field>
          <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="active" defaultChecked={!!v.active} className="h-4 w-4 accent-[#6A9FFF]" />Tampilkan di website</label>
        </ActionForm>
      </div>
    </>
  );
}

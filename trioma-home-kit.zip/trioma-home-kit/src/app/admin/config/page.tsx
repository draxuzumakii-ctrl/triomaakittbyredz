import { requireAdmin } from "@/lib/auth";
import { PageHeader } from "@/components/ui/bits";
import { ActionForm, Field } from "@/components/ui/action-form";
import { saveSiteConfig } from "../actions";
export const metadata = { title: "Konfigurasi website" };

export default async function Config() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from("system_settings").select("value").eq("key", "site").maybeSingle();
  const v = (data?.value ?? {}) as Record<string, string>;
  return (
    <>
      <PageHeader title="Konfigurasi website" sub="Nomor WhatsApp dipakai untuk tombol hubungi kasir di halaman pesanan dan kontak." />
      <div className="glass max-w-xl p-6">
        <ActionForm action={saveSiteConfig} className="space-y-4" submitLabel="Simpan konfigurasi">
          <Field name="store_name" label="Nama toko"><input id="store_name" name="store_name" className="field" defaultValue={v.store_name ?? "TRIOMA Home Kit"} /></Field>
          <Field name="whatsapp_number" label="Nomor WhatsApp kasir (format internasional, tanpa +)"><input id="whatsapp_number" name="whatsapp_number" className="field" defaultValue={v.whatsapp_number ?? ""} placeholder="6281234567890" inputMode="numeric" /></Field>
          <Field name="contact_email" label="Email kontak"><input id="contact_email" name="contact_email" type="email" className="field" defaultValue={v.contact_email ?? ""} /></Field>
          <Field name="contact_address" label="Alamat"><textarea id="contact_address" name="contact_address" className="field" defaultValue={v.contact_address ?? ""} /></Field>
        </ActionForm>
      </div>
    </>
  );
}

import { requireAdmin } from "@/lib/auth";
import { AdminNav } from "@/components/admin/admin-nav";

export const metadata = { title: { default: "Admin", template: "%s | Admin TRIOMA Home Kit" } };

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const { profile } = await requireAdmin();
  return (<><AdminNav role={profile.role} /><main className="mx-auto max-w-6xl px-4 pb-20 pt-8">{children}</main></>);
}

import type { Metadata } from "next";
export const metadata: Metadata = { title: "Teknologi" };

const layers = [
  ["Perangkat", "Pengendali ESP32-S3 membaca sensor gerak, pintu, suhu, dan mengendalikan Smart Switch. Modul Zigbee disiapkan sebagai tahap pengembangan berikutnya."],
  ["Platform", "Data tersimpan di PostgreSQL (Supabase). Setiap tabel dilindungi Row Level Security sehingga pengguna hanya membaca data rumahnya sendiri."],
  ["Realtime", "Notifikasi dan perubahan perangkat dikirim lewat Supabase Realtime tanpa perlu memuat ulang halaman."],
  ["Aplikasi", "Dashboard Next.js yang responsif, dengan validasi di sisi server untuk setiap input."],
];

export default function Technology() {
  return (
    <div className="mx-auto max-w-6xl px-6 pt-16">
      <h1 className="display text-5xl md:text-7xl">Teknologi</h1>
      <p className="prose-tight mt-5">Empat lapisan yang dirancang agar mudah dikembangkan dari simulasi menuju perangkat fisik.</p>
      <div className="mt-12 space-y-4">
        {layers.map(([t, d]) => (
          <div key={t} className="glass grid gap-3 p-7 md:grid-cols-[220px_1fr] md:gap-10"><h2 className="text-xl font-medium tracking-tight">{t}</h2><p className="prose-tight text-sm">{d}</p></div>
        ))}
      </div>
      <div className="solid mt-10 p-7">
        <h2 className="font-medium">Status integrasi perangkat</h2>
        <p className="prose-tight mt-2 text-sm">Integrasi hub ESP32-S3 dan Zigbee belum tersedia. Sampai saat itu, dashboard menyediakan Simulation Mode, dan seluruh data simulasi selalu diberi label &quot;Simulasi&quot;.</p>
      </div>
    </div>
  );
}

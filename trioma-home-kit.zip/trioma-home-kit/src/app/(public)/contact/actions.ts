"use server";
import { createClient } from "@/lib/supabase/server";
import { contactSchema, zodFail } from "@/lib/validation";
import type { ActionResult } from "@/lib/types";

/** Pesan kontak masuk sebagai notifikasi ke seluruh admin (lewat RPC aman di bawah). */
export async function sendContact(fd: FormData): Promise<ActionResult> {
  const parsed = contactSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return zodFail(parsed.error);
  const supabase = await createClient();
  const { error } = await supabase.rpc("submit_contact", { p_name: parsed.data.name, p_email: parsed.data.email, p_message: parsed.data.message });
  if (error) return { ok: false, message: "Pesan belum terkirim. Coba lagi atau hubungi lewat WhatsApp." };
  return { ok: true, message: "Pesan terkirim. Kami akan membalas lewat email." };
}

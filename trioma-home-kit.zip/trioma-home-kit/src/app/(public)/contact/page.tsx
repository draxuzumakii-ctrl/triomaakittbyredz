import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { ActionForm, Field } from "@/components/ui/action-form";
import { sendContact } from "./actions";
export const metadata: Metadata = { title: "Kontak" };

export default async function Contact() {
  const supabase = await createClient();
  const { data } = await supabase.from("system_settings").select("value").eq("key", "site").maybeSingle();
  const site = (data?.value ?? {}) as { whatsapp_number?: string; contact_email?: string; contact_address?: string };
  const wa = site.whatsapp_number?.replace(/\D/g, "");
  return (
    <div className="mx-auto grid max-w-5xl gap-12 px-6 pt-16 md:grid-cols-[1fr_1.2fr]">
      <div>
        <h1 className="display text-5xl md:text-6xl">Kontak</h1>
        <p className="prose-tight mt-5">Tanyakan paket, pemasangan, atau pesanan Anda.</p>
        <dl className="mt-8 space-y-3 text-sm">
          {site.contact_email && <div><dt className="text-silver/70">Email</dt><dd>{site.contact_email}</dd></div>}
          {site.contact_address && <div><dt className="text-silver/70">Alamat</dt><dd>{site.contact_address}</dd></div>}
        </dl>
        {wa && <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer" className="btn btn-glass mt-6">Chat WhatsApp kasir</a>}
      </div>
      <div className="glass p-7">
        <ActionForm action={sendContact} className="space-y-4" resetOnSuccess submitLabel="Kirim pesan" submitClass="btn btn-primary w-full">
          <Field name="name" label="Nama"><input id="name" name="name" className="field" autoComplete="name" /></Field>
          <Field name="email" label="Email"><input id="email" name="email" type="email" className="field" autoComplete="email" /></Field>
          <Field name="message" label="Pesan"><textarea id="message" name="message" className="field" /></Field>
        </ActionForm>
      </div>
    </div>
  );
}

import Link from "next/link";
import { Cpu, ShieldCheck, Zap, Radio, Smartphone } from "lucide-react";
import { HeroVisual } from "@/components/site/hero-visual";
import { SmartHomePreview } from "@/components/site/preview";
import { MagneticLink } from "@/components/magnetic";
import { createClient } from "@/lib/supabase/server";
import { rupiah } from "@/lib/format";
import type { Product } from "@/lib/types";

export const revalidate = 60;

export default async function Home() {
  const supabase = await createClient();
  const { data } = await supabase.from("products").select("*").eq("is_active", true).order("sort_order");
  const products = (data ?? []) as Product[];
  const packages = products.filter((p) => p.kind === "package");

  return (
    <>
      {/* HERO - asimetris, tipografi besar */}
      <section className="mx-auto grid max-w-6xl items-center gap-6 px-6 pb-10 pt-16 md:grid-cols-[1.15fr_1fr] md:pt-24">
        <div>
          <p className="mb-6 text-sm text-silver">TRIOMA Home Kit. Satu jaringan, tiga fungsi.</p>
          <h1 className="display text-[clamp(3.2rem,9vw,7.2rem)]">Your Home.<br />Under One<br />Intelligence.</h1>
          <p className="prose-tight mt-8 text-lg">Experience a smarter way to manage automation, security, and energy through one connected ecosystem.</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <MagneticLink href="/products" className="btn btn-primary">Explore TRIOMA</MagneticLink>
            <Link href="/auth/register?next=/dashboard" className="btn btn-glass">Experience Simulation</Link>
          </div>
        </div>
        <div className="-mr-6 md:-mr-24"><HeroVisual /></div>
      </section>

      {/* 1. Pengantar */}
      <section className="mx-auto mt-24 grid max-w-6xl gap-10 px-6 md:grid-cols-[1fr_1.4fr]">
        <h2 className="text-3xl font-semibold tracking-display md:text-4xl">Rumah pintar tidak harus rumit.</h2>
        <p className="prose-tight text-lg">TRIOMA Home Kit menggabungkan sensor, hub, dan aplikasi dalam satu jaringan. Anda memilih paket sesuai kebutuhan, memasangnya, lalu mengelola rumah dari satu dashboard. Perangkat berbasis ESP32-S3 dan disiapkan untuk pengembangan modul Zigbee.</p>
      </section>

      {/* 2. Tiga fungsi - tidak seragam: lebar kolom berbeda */}
      <section className="mx-auto mt-24 max-w-6xl px-6">
        <div className="grid gap-4 md:grid-cols-[1.3fr_1fr_1fr]">
          {[
            { Icon: Cpu, t: "Otomatisasi", d: "Atur rutinitas rumah. Mode Pergi mematikan perangkat dan menyiagakan keamanan dalam satu ketukan; Mode Pulang mengembalikannya." },
            { Icon: ShieldCheck, t: "Keamanan", d: "Pantau pintu dan gerakan, terima notifikasi, dan telusuri riwayat kejadian." },
            { Icon: Zap, t: "Efisiensi energi", d: "Lihat pemakaian listrik per perangkat dan matikan yang tidak perlu." },
          ].map(({ Icon, t, d }, i) => (
            <article key={t} className={`glass lit p-7 ${i === 0 ? "md:row-span-1 md:py-10" : ""}`}>
              <Icon size={22} className="text-electric" />
              <h3 className="mt-6 text-xl font-medium tracking-tight">{t}</h3>
              <p className="prose-tight mt-2 text-sm">{d}</p>
            </article>
          ))}
        </div>
      </section>

      {/* 3. Ekosistem produk (dari database) */}
      <section className="mx-auto mt-28 max-w-6xl px-6">
        <h2 className="text-3xl font-semibold tracking-display md:text-4xl">Ekosistem produk</h2>
        <p className="prose-tight mt-3">Tiga paket untuk tiga kebutuhan, ditambah kamera untuk pemantauan visual.</p>
        {products.length === 0 ? (
          <p className="solid mt-8 p-6 text-sm text-silver">Katalog belum tersedia. Silakan kembali lagi nanti.</p>
        ) : (
          <div className="mt-8 grid gap-4 md:grid-cols-4">
            {products.map((p) => (
              <Link key={p.id} href={`/products/${p.slug}`} className="glass lit group flex flex-col justify-between p-6 transition-transform hover:-translate-y-0.5">
                <div>
                  <p className="text-xs text-silver/70">{p.focus}</p>
                  <h3 className="mt-2 text-xl font-medium tracking-tight">{p.name}</h3>
                  <p className="prose-tight mt-2 text-sm">{p.tagline}</p>
                </div>
                <p className="mt-10 text-lg font-semibold">{rupiah(p.price_idr)}</p>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* 4. Cara kerja - urutan nyata */}
      <section className="mx-auto mt-28 max-w-6xl px-6">
        <h2 className="text-3xl font-semibold tracking-display md:text-4xl">Cara TRIOMA bekerja</h2>
        <ol className="mt-10 grid gap-8 md:grid-cols-3">
          {[
            { Icon: Radio, t: "Hub", d: "Pusat kendali yang menghubungkan semua perangkat di rumah." },
            { Icon: Cpu, t: "Sensor", d: "Mendeteksi gerakan, pintu, suhu, dan beban listrik." },
            { Icon: Smartphone, t: "Aplikasi", d: "Kontrol dan pantau dari dashboard, di mana saja." },
          ].map(({ Icon, t, d }, i) => (
            <li key={t} className="relative border-t border-white/[.12] pt-6">
              <span className="absolute -top-px left-0 h-px w-16 bg-electric" />
              <p className="text-sm text-electric">Langkah {i + 1}</p>
              <h3 className="mt-2 flex items-center gap-2 text-xl font-medium"><Icon size={18} />{t}</h3>
              <p className="prose-tight mt-2 text-sm">{d}</p>
            </li>
          ))}
        </ol>
      </section>

      {/* 5. Pratinjau */}
      <section className="mx-auto mt-28 max-w-6xl px-6"><SmartHomePreview /></section>

      {/* 6. Paket */}
      <section className="mx-auto mt-28 max-w-6xl px-6">
        <h2 className="text-3xl font-semibold tracking-display md:text-4xl">Pilih paket Anda</h2>
        <div className="mt-8 divide-y divide-white/[.08] border-y border-white/[.08]">
          {packages.map((p) => (
            <Link key={p.id} href={`/products/${p.slug}`} className="group grid items-center gap-2 py-6 transition-colors hover:bg-white/[.025] md:grid-cols-[1fr_1.4fr_auto_auto] md:gap-8 md:px-4">
              <h3 className="text-2xl font-semibold tracking-tight">{p.name}</h3>
              <p className="prose-tight text-sm">{p.tagline}</p>
              <p className="font-semibold">{rupiah(p.price_idr)}</p>
              <span className={`text-sm ${p.stock > 0 ? "text-[var(--ok)]" : "text-[var(--bad)]"}`}>{p.stock > 0 ? "Tersedia" : "Stok habis"}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* 7. Arsitektur teknis */}
      <section className="mx-auto mt-28 max-w-6xl px-6">
        <h2 className="text-3xl font-semibold tracking-display md:text-4xl">Arsitektur teknis</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {[
            ["Perangkat", "ESP32-S3 sebagai pengendali; modul Zigbee disiapkan untuk tahap berikutnya."],
            ["Platform", "Next.js dan Supabase (PostgreSQL, Auth, Realtime) dengan Row Level Security."],
            ["Aplikasi", "Dashboard responsif dengan notifikasi waktu nyata dan Simulation Mode yang berlabel jelas."],
          ].map(([t, d]) => (
            <div key={t} className="solid p-6"><h3 className="font-medium">{t}</h3><p className="prose-tight mt-2 text-sm">{d}</p></div>
          ))}
        </div>
      </section>

      {/* 8. CTA akhir */}
      <section className="mx-auto mt-28 max-w-6xl px-6">
        <div className="glass flex flex-col items-start justify-between gap-6 p-10 md:flex-row md:items-center md:p-14">
          <h2 className="display max-w-xl text-4xl md:text-5xl">Mulai dengan satu paket.</h2>
          <div className="flex gap-3"><Link href="/products" className="btn btn-primary">Lihat produk</Link><Link href="/contact" className="btn btn-glass">Hubungi kami</Link></div>
        </div>
      </section>
    </>
  );
}

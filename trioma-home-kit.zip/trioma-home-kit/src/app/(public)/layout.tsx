import { SiteNav } from "@/components/site/site-nav";
import { SiteFooter } from "@/components/site/site-footer";
import { Announcement } from "@/components/site/announcement";
import { createClient } from "@/lib/supabase/server";

export default async function PublicLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return (
    <>
      <Announcement />
      <SiteNav signedIn={!!user} />
      <main>{children}</main>
      <SiteFooter />
    </>
  );
}

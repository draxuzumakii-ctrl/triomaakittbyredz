import type { Metadata } from "next";
export const metadata: Metadata = { title: "Tentang TRIOMA" };

export default function About() {
  return (
    <div className="mx-auto max-w-4xl px-6 pt-16">
      <h1 className="display text-5xl md:text-7xl">Tentang TRIOMA</h1>
      <div className="prose-tight mt-8 space-y-5 text-lg">
        <p>TRIOMA Home Kit dirancang agar rumah pintar terjangkau dan mudah dipahami. Alih-alih banyak aplikasi untuk banyak perangkat, TRIOMA menyatukan tiga fungsi dalam satu jaringan.</p>
        <p>Tiga fungsi itu adalah otomatisasi untuk kenyamanan, keamanan untuk ketenangan, dan efisiensi energi untuk penghematan.</p>
        <p>Kami terbuka soal tahap pengembangan: dashboard sudah berjalan dengan Simulation Mode, sementara integrasi perangkat fisik ESP32-S3 dan Zigbee dikerjakan bertahap.</p>
      </div>
    </div>
  );
}

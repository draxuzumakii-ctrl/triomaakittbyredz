import type { Metadata } from "next";
import Link from "next/link";
export const metadata: Metadata = { title: "Cara Kerja" };

const steps = [
  ["Pilih paket", "Pilih Paket TERAS, JAGA, atau HEMAT sesuai kebutuhan, lalu tambahkan TRIOMA Cam bila perlu."],
  ["Pesan dan pantau", "Kirim pesanan, lalu pantau statusnya dari Menunggu hingga Selesai di dashboard."],
  ["Pasang hub dan sensor", "Hub menjadi pusat jaringan. Sensor dan Smart Switch dipasang di ruangan yang Anda inginkan."],
  ["Atur ruangan dan otomatisasi", "Kelompokkan perangkat per ruangan, lalu aktifkan Mode Pergi, Mode Pulang, atau otomatisasi buatan Anda."],
];

export default function HowItWorks() {
  return (
    <div className="mx-auto max-w-4xl px-6 pt-16">
      <h1 className="display text-5xl md:text-7xl">Cara kerja</h1>
      <ol className="mt-14 space-y-0">
        {steps.map(([t, d], i) => (
          <li key={t} className="grid gap-4 border-t border-white/10 py-8 md:grid-cols-[120px_1fr]">
            <span className="text-sm text-electric">Langkah {i + 1}</span>
            <div><h2 className="text-2xl font-semibold tracking-tight">{t}</h2><p className="prose-tight mt-2">{d}</p></div>
          </li>
        ))}
      </ol>
      <p className="prose-tight mt-6 text-sm">Belum punya perangkat? Buat akun dan coba dashboard dengan Simulation Mode.</p>
      <Link href="/auth/register" className="btn btn-primary mt-5">Buat akun</Link>
    </div>
  );
}

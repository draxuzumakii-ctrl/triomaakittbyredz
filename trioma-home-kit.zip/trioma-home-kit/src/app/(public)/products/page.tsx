import Link from "next/link";
import Image from "next/image";
import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { rupiah } from "@/lib/format";
import { EmptyState, ErrorState } from "@/components/ui/bits";
import type { Product } from "@/lib/types";

export const metadata: Metadata = { title: "Produk" };
export const revalidate = 60;

export default async function ProductsPage() {
  const supabase = await createClient();
  const { data, error } = await supabase.from("products").select("*").eq("is_active", true).order("sort_order");
  const products = (data ?? []) as Product[];
  return (
    <div className="mx-auto max-w-6xl px-6 pt-16">
      <h1 className="display text-5xl md:text-7xl">Produk</h1>
      <p className="prose-tight mt-5">Pilih paket sesuai kebutuhan rumah Anda. Harga dan ketersediaan selalu diperbarui dari katalog.</p>
      <div className="mt-12">
        {error ? <ErrorState body="Katalog tidak dapat dimuat saat ini." retryHref="/products" />
          : products.length === 0 ? <EmptyState title="Belum ada produk" body="Katalog sedang disiapkan." />
          : (
            <div className="grid gap-5 md:grid-cols-2">
              {products.map((p, i) => (
                <Link key={p.id} href={`/products/${p.slug}`} className={`glass lit flex flex-col overflow-hidden transition-transform hover:-translate-y-0.5 ${i === 0 ? "md:col-span-2 md:flex-row" : ""}`}>
                  <div className={`relative grid place-items-center bg-[#0b0e15] ${i === 0 ? "min-h-[240px] md:w-1/2" : "h-48"}`}>
                    {p.image_url ? <Image src={p.image_url} alt={p.name} fill className="object-cover" sizes="(min-width:768px) 50vw, 100vw" />
                      : <span className="text-sm text-silver/50">Foto produk belum diunggah</span>}
                  </div>
                  <div className="flex flex-1 flex-col justify-between gap-8 p-7">
                    <div>
                      <p className="text-xs text-silver/70">{p.focus}</p>
                      <h2 className="mt-1 text-2xl font-semibold tracking-tight">{p.name}</h2>
                      <p className="prose-tight mt-2 text-sm">{p.tagline}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-xl font-semibold">{rupiah(p.price_idr)}</p>
                      <span className={`text-sm ${p.stock > 0 ? "text-[var(--ok)]" : "text-[var(--bad)]"}`}>{p.stock > 0 ? `Stok ${p.stock}` : "Stok habis"}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
      </div>
    </div>
  );
}

import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { rupiah } from "@/lib/format";
import { OrderForm } from "./order-form";
import type { PackageItem, Product } from "@/lib/types";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const supabase = await createClient();
  const { data } = await supabase.from("products").select("name,tagline").eq("slug", slug).maybeSingle();
  return { title: data?.name ?? "Produk", description: data?.tagline };
}

export default async function ProductDetail({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const supabase = await createClient();
  const { data: p } = await supabase.from("products").select("*").eq("slug", slug).maybeSingle();
  if (!p) notFound();
  const product = p as Product;
  const { data: items } = await supabase.from("product_packages").select("*").eq("product_id", product.id).order("sort_order");
  const { data: { user } } = await supabase.auth.getUser();
  const profile = user ? (await supabase.from("profiles").select("full_name,phone").eq("id", user.id).single()).data : null;
  const available = product.stock > 0;

  return (
    <div className="mx-auto grid max-w-6xl gap-10 px-6 pt-14 md:grid-cols-[1.2fr_1fr]">
      <div>
        <Link href="/products" className="text-sm text-silver hover:text-white">Semua produk</Link>
        <div className="glass relative mt-4 grid aspect-[4/3] place-items-center overflow-hidden">
          {product.image_url ? <Image src={product.image_url} alt={product.name} fill className="object-cover" sizes="(min-width:768px) 60vw, 100vw" priority />
            : <span className="text-sm text-silver/50">Foto produk belum diunggah</span>}
        </div>
        <h1 className="display mt-8 text-5xl md:text-6xl">{product.name}</h1>
        <p className="mt-2 text-silver">{product.tagline}</p>
        <p className="prose-tight mt-6">{product.description}</p>

        <h2 className="mt-12 text-xl font-medium tracking-tight">Isi paket</h2>
        {(items as PackageItem[] | null)?.length ? (
          <ul className="mt-4 divide-y divide-white/[.08] border-y border-white/[.08] text-sm">
            {(items as PackageItem[]).map((i) => (
              <li key={i.id} className="flex justify-between py-3"><span>{i.item_name}{i.notes && <span className="text-silver/60"> ({i.notes})</span>}</span><span className="text-silver">{i.quantity} unit</span></li>
            ))}
          </ul>
        ) : <p className="mt-3 text-sm text-silver">Isi paket belum dicantumkan.</p>}

        <h2 className="mt-12 text-xl font-medium tracking-tight">Spesifikasi teknis</h2>
        {product.specs?.length ? (
          <dl className="mt-4 divide-y divide-white/[.08] border-y border-white/[.08] text-sm">
            {product.specs.map((s) => (<div key={s.label} className="flex justify-between gap-6 py-3"><dt className="text-silver">{s.label}</dt><dd className="text-right">{s.value}</dd></div>))}
          </dl>
        ) : <p className="mt-3 text-sm text-silver">Spesifikasi belum dicantumkan.</p>}
      </div>

      <aside className="md:sticky md:top-24 md:self-start">
        <div className="glass p-7">
          <p className="text-3xl font-semibold tracking-tight">{rupiah(product.price_idr)}</p>
          <p className={`mt-1 text-sm ${available ? "text-[var(--ok)]" : "text-[var(--bad)]"}`}>{available ? `Tersedia, stok ${product.stock}` : "Stok habis"}</p>
          <div className="mt-6">
            {!available ? <p className="text-sm text-silver">Produk ini sedang tidak dapat dipesan.</p>
              : !user ? (
                <div className="space-y-3">
                  <p className="text-sm text-silver">Masuk atau buat akun agar status pesanan dapat Anda pantau.</p>
                  <Link href={`/auth/login?next=/products/${product.slug}`} className="btn btn-primary w-full">Masuk untuk memesan</Link>
                  <Link href={`/auth/register?next=/products/${product.slug}`} className="btn btn-glass w-full">Buat akun</Link>
                </div>
              ) : <OrderForm productId={product.id} price={product.price_idr} stock={product.stock} defaults={{ name: profile?.full_name ?? "", phone: profile?.phone ?? "" }} />}
          </div>
        </div>
      </aside>
    </div>
  );
}

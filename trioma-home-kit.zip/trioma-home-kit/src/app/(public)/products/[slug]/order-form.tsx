"use client";
import { useState } from "react";
import { ActionForm, Field } from "@/components/ui/action-form";
import { rupiah } from "@/lib/format";
import { placeOrder } from "./actions";

export function OrderForm({ productId, price, stock, defaults }: { productId: string; price: number; stock: number; defaults: { name: string; phone: string } }) {
  const [qty, setQty] = useState(1);
  const safeQty = Math.min(Math.max(qty || 1, 1), Math.max(stock, 1));
  return (
    <ActionForm action={placeOrder} className="space-y-4" submitLabel="Kirim pesanan" submitClass="btn btn-primary w-full">
      <input type="hidden" name="product_id" value={productId} />
      <Field name="quantity" label="Jumlah">
        <input id="quantity" name="quantity" type="number" min={1} max={stock} value={qty} onChange={(e) => setQty(Number(e.target.value))} className="field" inputMode="numeric" />
      </Field>
      <Field name="customer_name" label="Nama penerima"><input id="customer_name" name="customer_name" className="field" defaultValue={defaults.name} autoComplete="name" /></Field>
      <Field name="phone" label="Nomor telepon / WhatsApp"><input id="phone" name="phone" className="field" defaultValue={defaults.phone} inputMode="tel" autoComplete="tel" /></Field>
      <Field name="address" label="Alamat pengiriman"><textarea id="address" name="address" className="field" autoComplete="street-address" /></Field>
      <Field name="notes" label="Catatan (opsional)"><input id="notes" name="notes" className="field" /></Field>
      <div className="flex items-center justify-between border-t border-white/10 pt-4 text-sm">
        <span className="text-silver">Total</span><span className="text-lg font-semibold">{rupiah(price * safeQty)}</span>
      </div>
    </ActionForm>
  );
}

"use server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { orderSchema, zodFail } from "@/lib/validation";
import type { ActionResult } from "@/lib/types";

export async function placeOrder(fd: FormData): Promise<ActionResult | void> {
  const parsed = orderSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return zodFail(parsed.error);
  const v = parsed.data;

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { ok: false, message: "Masuk dulu untuk mengirim pesanan." };

  const { data, error } = await supabase.rpc("place_order", {
    p_product: v.product_id, p_qty: v.quantity, p_name: v.customer_name,
    p_phone: v.phone, p_address: v.address, p_notes: v.notes,
  });
  if (error) return { ok: false, message: error.message.includes("Stok") || error.message.includes("Jumlah") ? error.message : "Pesanan gagal dikirim. Coba lagi." };
  redirect(`/dashboard/orders?baru=${data}`);
}

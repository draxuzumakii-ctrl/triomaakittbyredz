import Link from "next/link";
export default function NotFound() {
  return (
    <main className="grid min-h-dvh place-items-center px-6">
      <div className="max-w-md">
        <h1 className="display text-6xl">Halaman tidak ditemukan</h1>
        <p className="prose-tight mt-4">Alamat yang Anda buka tidak ada atau sudah dipindahkan.</p>
        <Link href="/" className="btn btn-primary mt-7">Kembali ke beranda</Link>
      </div>
    </main>
  );
}

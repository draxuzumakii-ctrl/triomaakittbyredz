import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { EmptyState, PageHeader, StatusPill } from "@/components/ui/bits";
import { dateTime, rupiah, statusLabel } from "@/lib/format";
import type { Order } from "@/lib/types";
export const metadata = { title: "Pesanan" };

const steps = ["pending", "confirmed", "processing", "completed"];

export default async function OrdersPage({ searchParams }: { searchParams: Promise<{ baru?: string }> }) {
  const { baru } = await searchParams;
  const { supabase } = await requireUser();
  const [{ data }, { data: s }] = await Promise.all([
    supabase.from("orders").select("*, order_items(quantity, unit_price_idr, products(name))").order("created_at", { ascending: false }),
    supabase.from("system_settings").select("value").eq("key", "site").maybeSingle(),
  ]);
  const wa = ((s?.value as any)?.whatsapp_number ?? "").replace(/\D/g, "");
  const orders = (data ?? []) as (Order & { order_items: { quantity: number; unit_price_idr: number; products: { name: string } | null }[] })[];
  return (
    <>
      <PageHeader title="Pesanan" sub="Pantau status pesanan Anda." right={<Link href="/products" className="btn btn-glass btn-sm">Lihat produk</Link>} />
      {baru && <p className="solid mb-5 border-[rgba(95,211,154,.35)] px-4 py-3 text-sm text-[#a6efcb]" role="status">Pesanan terkirim. Admin akan segera mengonfirmasi.</p>}
      {orders.length === 0 ? <EmptyState title="Belum ada pesanan" body="Pilih paket TRIOMA Home Kit untuk memulai." action={<Link href="/products" className="btn btn-primary">Lihat produk</Link>} /> : (
        <ul className="space-y-4">
          {orders.map((o) => {
            const idx = steps.indexOf(o.status);
            const item = o.order_items[0];
            const text = encodeURIComponent(`Halo, saya ingin menanyakan pesanan ${o.code} (${item?.products?.name ?? "TRIOMA Home Kit"} x${item?.quantity ?? 1}).`);
            return (
              <li key={o.id} className="glass p-6">
                <div className="flex flex-wrap items-center justify-between gap-3"><p className="font-mono text-sm">{o.code}</p><StatusPill status={o.status} /></div>
                <p className="mt-3 font-medium">{o.order_items.map((i) => `${i.products?.name ?? "Produk"} x${i.quantity}`).join(", ")}</p>
                <p className="text-sm text-silver">{rupiah(o.total_idr)}, dipesan {dateTime(o.created_at)}</p>
                {o.status !== "cancelled" ? (
                  <ol className="mt-5 grid grid-cols-4 gap-2 text-xs" aria-label="Progres pesanan">
                    {steps.map((st, i) => <li key={st}><div className={`h-1 rounded-full ${i <= idx ? "bg-electric" : "bg-white/[.12]"}`} /><p className={`mt-1.5 ${i <= idx ? "text-white" : "text-silver/50"}`}>{statusLabel[st]}</p></li>)}
                  </ol>
                ) : <p className="mt-4 text-sm text-[#ffb3bb]">Pesanan dibatalkan.</p>}
                {wa && <a href={`https://wa.me/${wa}?text=${text}`} target="_blank" rel="noopener noreferrer" className="btn btn-glass btn-sm mt-5">Hubungi kasir via WhatsApp</a>}
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}

import Link from "next/link";
import { Thermometer, Droplets, ShieldCheck, Zap, Radio } from "lucide-react";
import { requireUser } from "@/lib/auth";
import { PageHeader, SimBadge } from "@/components/ui/bits";
import { NoDevices } from "@/components/dash/sim-prompt";
import { ActionButton } from "@/components/ui/action-form";
import { runMode } from "./actions";
import { timeAgo, deviceLabel } from "@/lib/format";
import type { ActivityLog, Device } from "@/lib/types";

export const metadata = { title: "Beranda" };

export default async function Overview() {
  const { supabase, profile } = await requireUser();
  const [{ data: d }, { data: l }] = await Promise.all([
    supabase.from("devices").select("*").order("created_at"),
    supabase.from("activity_logs").select("*").order("created_at", { ascending: false }).limit(6),
  ]);
  const devices = (d ?? []) as Device[]; const logs = (l ?? []) as ActivityLog[];
  const sim = devices.some((x) => x.is_simulated);
  const real = devices.filter((x) => !x.is_simulated && x.is_online);
  const temp = devices.find((x) => x.type === "temperature_sensor" && x.is_online);
  const switches = devices.filter((x) => x.type === "smart_switch" && x.is_online);
  const watts = switches.reduce((s, x) => s + (x.state.on ? Number(x.state.rated_watts ?? 0) : 0), 0);
  const alert = devices.some((x) => (x.type === "door_sensor" && x.state.open) || (x.type === "motion_sensor" && x.state.motion));
  const security = devices.some((x) => x.type === "door_sensor" || x.type === "motion_sensor")
    ? alert ? "Perlu dicek" : profile.security_armed ? "Siaga" : "Tidak siaga" : "Belum ada sensor";
  const online = devices.filter((x) => x.is_online).length;
  const hour = new Date().getHours();
  const greet = hour < 11 ? "Selamat pagi" : hour < 15 ? "Selamat siang" : hour < 19 ? "Selamat sore" : "Selamat malam";

  const stats = [
    { Icon: Thermometer, label: "Suhu ruangan", value: temp ? `${temp.state.temperature_c}°C` : "Belum ada data", simulated: temp?.is_simulated },
    { Icon: Droplets, label: "Kelembapan", value: temp ? `${temp.state.humidity}%` : "Belum ada data", simulated: temp?.is_simulated },
    { Icon: ShieldCheck, label: "Status keamanan", value: security, simulated: devices.some((x) => x.is_simulated && (x.type === "door_sensor" || x.type === "motion_sensor")) },
    { Icon: Zap, label: "Beban listrik", value: switches.length ? `${watts} W` : "Belum ada data", simulated: switches.some((x) => x.is_simulated) },
  ];

  return (
    <>
      <PageHeader title={`${greet}, ${profile.full_name.split(" ")[0] || "selamat datang"}`}
        sub={devices.length ? (alert ? "Ada kejadian keamanan yang perlu Anda cek." : "Ringkasan rumah Anda.") : "Mulai dengan menambahkan perangkat."}
        right={sim && <SimBadge />} />
      {sim && <p className="solid mb-6 border-[rgba(242,180,90,.3)] px-4 py-3 text-sm text-[#f6d9a6]">Simulation Mode: perangkat dan pembacaan bertanda Simulasi bukan berasal dari sensor fisik.</p>}
      {devices.length === 0 ? <NoDevices /> : (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {stats.map((s) => (
              <div key={s.label} className="glass lit p-4">
                <s.Icon size={18} className="text-electric" />
                <p className="mt-4 text-xl font-semibold tracking-tight">{s.value}</p>
                <p className="mt-0.5 flex items-center gap-2 text-xs text-silver/80">{s.label}{s.simulated && <SimBadge />}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 grid gap-4 lg:grid-cols-[1.3fr_1fr]">
            <section className="glass p-6">
              <h2 className="flex items-center gap-2 font-medium"><Radio size={17} className="text-electric" />Status hub</h2>
              <p className="mt-3 text-sm text-silver">
                {real.length ? `${real.length} perangkat fisik terhubung.` : "Belum ada hub fisik yang terhubung."}
                {sim && " Perangkat simulasi aktif."}
              </p>
              <p className="mt-1 text-sm text-silver/70">{online} dari {devices.length} perangkat online.</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <ActionButton action={runMode.bind(null, "pergi")} className="btn btn-glass">Mode Pergi</ActionButton>
                <ActionButton action={runMode.bind(null, "pulang")} className="btn btn-primary">Mode Pulang</ActionButton>
              </div>
              <p className="mt-3 text-xs text-silver/60">Mode terakhir: {profile.home_mode === "pergi" ? "Pergi" : "Pulang"}</p>
            </section>
            <section className="glass p-6">
              <div className="flex items-center justify-between"><h2 className="font-medium">Aktivitas terbaru</h2><Link href="/dashboard/history" className="text-xs text-electric">Lihat semua</Link></div>
              {logs.length === 0 ? <p className="mt-4 text-sm text-silver">Belum ada aktivitas.</p> : (
                <ul className="mt-4 space-y-3">
                  {logs.map((a) => (
                    <li key={a.id} className="text-sm"><p>{a.message}</p><p className="mt-0.5 flex items-center gap-2 text-xs text-silver/60">{timeAgo(a.created_at)}{a.source === "simulation" && <SimBadge />}</p></li>
                  ))}
                </ul>
              )}
            </section>
          </div>
          <section className="glass mt-4 p-6">
            <div className="flex items-center justify-between"><h2 className="font-medium">Perangkat aktif</h2><Link href="/dashboard/devices" className="text-xs text-electric">Kelola</Link></div>
            <ul className="mt-3 divide-y divide-white/[.08]">
              {devices.slice(0, 5).map((x) => (
                <li key={x.id} className="flex items-center justify-between py-2.5 text-sm">
                  <span className="flex items-center gap-2">{x.name}<span className="text-xs text-silver/60">{deviceLabel[x.type]}</span>{x.is_simulated && <SimBadge />}</span>
                  <span className="flex items-center gap-2 text-silver"><span className={`dot ${x.is_online ? "dot-ok" : ""}`} />{x.is_online ? "Online" : "Offline"}</span>
                </li>
              ))}
            </ul>
          </section>
        </>
      )}
    </>
  );
}

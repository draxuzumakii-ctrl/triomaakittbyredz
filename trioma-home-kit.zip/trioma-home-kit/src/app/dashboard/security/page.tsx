import { requireUser } from "@/lib/auth";
import { PageHeader, SimBadge } from "@/components/ui/bits";
import { NoDevices } from "@/components/dash/sim-prompt";
import { ActionButton, ToggleSwitch } from "@/components/ui/action-form";
import { clearSecurityEvents, setArmed, simulateSecurityEvent } from "../actions";
import { timeAgo } from "@/lib/format";
import type { ActivityLog, Device } from "@/lib/types";
export const metadata = { title: "Keamanan" };

export default async function SecurityPage() {
  const { supabase, profile } = await requireUser();
  const [{ data: d }, { data: l }] = await Promise.all([
    supabase.from("devices").select("*").in("type", ["motion_sensor", "door_sensor", "cam"]),
    supabase.from("activity_logs").select("*").eq("category", "security").order("created_at", { ascending: false }).limit(12),
  ]);
  const devices = (d ?? []) as Device[]; const logs = (l ?? []) as ActivityLog[];
  const hasSim = devices.some((x) => x.is_simulated);
  return (
    <>
      <PageHeader title="Keamanan" sub="Pantau pintu, gerakan, dan kamera." />
      {devices.length === 0 ? <NoDevices /> : (
        <>
          <section className="glass flex flex-wrap items-center justify-between gap-4 p-6">
            <div><h2 className="text-xl font-medium tracking-tight">{profile.security_armed ? "Keamanan siaga" : "Keamanan tidak siaga"}</h2><p className="mt-1 text-sm text-silver">Saat siaga, kejadian sensor mengirim notifikasi.</p></div>
            <ToggleSwitch checked={profile.security_armed} label="Siagakan keamanan" action={setArmed} />
          </section>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {devices.map((x) => {
              const alert = (x.type === "door_sensor" && x.state.open) || (x.type === "motion_sensor" && x.state.motion);
              return (
                <div key={x.id} className="glass p-5">
                  <div className="flex items-center justify-between"><p className="font-medium">{x.name}</p>{x.is_simulated && <SimBadge />}</div>
                  <p className={`mt-3 flex items-center gap-2 text-sm ${alert ? "text-[#ffb3bb]" : "text-silver"}`}><span className={`dot ${alert ? "dot-bad" : x.is_online ? "dot-ok" : ""}`} />
                    {x.type === "cam" ? (x.state.recording ? "Merekam" : "Siaga") : x.type === "door_sensor" ? (x.state.open ? "Pintu terbuka" : "Pintu tertutup") : (x.state.motion ? "Gerakan terdeteksi" : "Tidak ada gerakan")}</p>
                </div>
              );
            })}
          </div>
          {hasSim && (
            <section className="glass mt-4 p-6">
              <h2 className="flex items-center gap-2 font-medium">Uji kejadian <SimBadge /></h2>
              <p className="mt-1 text-sm text-silver/80">Picu kejadian simulasi untuk menguji notifikasi dan otomatisasi Anda.</p>
              <div className="mt-4 flex flex-wrap gap-3">
                <ActionButton action={simulateSecurityEvent.bind(null, "motion")} className="btn btn-glass btn-sm">Simulasikan gerakan</ActionButton>
                <ActionButton action={simulateSecurityEvent.bind(null, "door_open")} className="btn btn-glass btn-sm">Simulasikan pintu terbuka</ActionButton>
                <ActionButton action={clearSecurityEvents} className="btn btn-glass btn-sm">Reset status sensor</ActionButton>
              </div>
            </section>
          )}
          <h2 className="mb-3 mt-8 text-lg font-medium">Kejadian terbaru</h2>
          {logs.length === 0 ? <p className="text-sm text-silver">Belum ada kejadian keamanan.</p> : (
            <ul className="divide-y divide-white/[.08] text-sm">{logs.map((x) => <li key={x.id} className="flex items-center justify-between gap-3 py-3"><span className="flex items-center gap-2">{x.message}{x.source === "simulation" && <SimBadge />}</span><span className="shrink-0 text-xs text-silver/60">{timeAgo(x.created_at)}</span></li>)}</ul>
          )}
        </>
      )}
    </>
  );
}

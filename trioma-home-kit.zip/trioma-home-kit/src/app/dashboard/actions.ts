"use server";
import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { automationSchema, deviceSchema, zodFail } from "@/lib/validation";
import { z } from "zod";
import type { ActionResult, Device } from "@/lib/types";

type Ctx = Awaited<ReturnType<typeof requireUser>>;
const refresh = () => revalidatePath("/dashboard", "layout");
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const r1 = (n: number) => Math.round(n * 10) / 10;

async function log(c: Ctx, category: string, message: string, source: "device" | "simulation" | "user" | "system", device_id?: string) {
  await c.supabase.from("activity_logs").insert({ user_id: c.user.id, category, message, source, device_id: device_id ?? null });
}
async function notify(c: Ctx, title: string, body: string, level: "info" | "success" | "warning" | "critical" = "info") {
  await c.supabase.from("notifications").insert({ user_id: c.user.id, title, body, level });
}
const defaultState = (type: string) =>
  type === "motion_sensor" ? { motion: false } : type === "door_sensor" ? { open: false }
  : type === "temperature_sensor" ? { temperature_c: 27, humidity: 65 } : type === "smart_switch" ? { on: false, rated_watts: 40 } : { recording: false };

/* ---------- Simulation Mode ---------- */
export async function enableSimulation(): Promise<ActionResult> {
  const c = await requireUser();
  const { count } = await c.supabase.from("devices").select("id", { count: "exact", head: true }).eq("is_simulated", true);
  if (count) return { ok: false, message: "Simulation Mode sudah aktif." };
  const { data: rooms, error } = await c.supabase.from("rooms").upsert(
    [{ user_id: c.user.id, name: "Ruang Tamu" }, { user_id: c.user.id, name: "Teras" }], { onConflict: "user_id,name" }).select();
  if (error || !rooms) return { ok: false, message: "Gagal menyiapkan ruangan." };
  const room = (n: string) => rooms.find((r) => r.name === n)?.id ?? null;
  const now = new Date().toISOString();
  const mk = (name: string, type: string, room_id: string | null) => ({ user_id: c.user.id, name, type, room_id, is_simulated: true, is_online: true, last_seen: now, state: defaultState(type) });
  const { error: e2 } = await c.supabase.from("devices").insert([
    mk("Sensor Gerak", "motion_sensor", room("Ruang Tamu")), mk("Sensor Pintu", "door_sensor", room("Teras")),
    mk("Sensor Suhu", "temperature_sensor", room("Ruang Tamu")), mk("Smart Switch", "smart_switch", room("Teras")), mk("TRIOMA Cam", "cam", room("Teras")),
  ]);
  if (e2) return { ok: false, message: "Gagal membuat perangkat simulasi." };
  const { count: ac } = await c.supabase.from("automations").select("id", { count: "exact", head: true }).in("kind", ["pergi", "pulang"]);
  if (!ac) await c.supabase.from("automations").insert([
    { user_id: c.user.id, name: "Mode Pergi", kind: "pergi", trigger_type: "manual", action_type: "switches_off" },
    { user_id: c.user.id, name: "Mode Pulang", kind: "pulang", trigger_type: "manual", action_type: "switches_on" },
  ]);
  await log(c, "system", "Simulation Mode diaktifkan. Semua perangkat berikut adalah simulasi.", "simulation");
  refresh(); return { ok: true, message: "Simulation Mode aktif. Perangkat berlabel Simulasi." };
}

export async function resetSimulation(): Promise<ActionResult> {
  const c = await requireUser();
  await c.supabase.from("devices").delete().eq("is_simulated", true);
  await log(c, "system", "Data Simulation Mode dihapus.", "system");
  refresh(); return { ok: true, message: "Perangkat simulasi dihapus." };
}

async function myDevices(c: Ctx) {
  const { data } = await c.supabase.from("devices").select("*");
  return (data ?? []) as Device[];
}

/* ---------- Otomatisasi: eksekusi aksi ---------- */
async function execAction(c: Ctx, action: string, label: string): Promise<string> {
  const devs = await myDevices(c);
  const switches = devs.filter((d) => d.type === "smart_switch");
  const sim = switches.length > 0 && switches.every((d) => d.is_simulated);
  const src = sim ? "simulation" : "user";
  if (action === "switches_off" || action === "switches_on") {
    const on = action === "switches_on";
    for (const s of switches) await c.supabase.from("devices").update({ state: { ...s.state, on }, last_seen: new Date().toISOString() }).eq("id", s.id);
    await log(c, "automation", `${label}: ${switches.length} Smart Switch ${on ? "dinyalakan" : "dimatikan"}.`, src);
    return `${switches.length} Smart Switch ${on ? "dinyalakan" : "dimatikan"}`;
  }
  if (action === "arm_security" || action === "disarm_security") {
    const armed = action === "arm_security";
    await c.supabase.from("profiles").update({ security_armed: armed }).eq("id", c.user.id);
    await log(c, "security", `${label}: keamanan ${armed ? "disiagakan" : "dinonaktifkan"}.`, "user");
    return `Keamanan ${armed ? "disiagakan" : "dinonaktifkan"}`;
  }
  await notify(c, label, "Otomatisasi Anda berjalan.", "info");
  await log(c, "automation", `${label}: notifikasi dikirim.`, "user");
  return "Notifikasi dikirim";
}

export async function runMode(mode: "pergi" | "pulang"): Promise<ActionResult> {
  const c = await requireUser();
  const label = mode === "pergi" ? "Mode Pergi" : "Mode Pulang";
  await execAction(c, mode === "pergi" ? "switches_off" : "switches_on", label);
  await execAction(c, mode === "pergi" ? "arm_security" : "disarm_security", label);
  await c.supabase.from("profiles").update({ home_mode: mode }).eq("id", c.user.id);
  await c.supabase.from("automations").update({ last_run_at: new Date().toISOString() }).eq("kind", mode);
  refresh(); return { ok: true, message: `${label} dijalankan.` };
}

export async function runAutomation(id: string): Promise<ActionResult> {
  const c = await requireUser();
  const { data: a } = await c.supabase.from("automations").select("*").eq("id", id).single();
  if (!a) return { ok: false, message: "Otomatisasi tidak ditemukan." };
  if (a.kind === "pergi" || a.kind === "pulang") return runMode(a.kind);
  const res = await execAction(c, a.action_type, a.name);
  await c.supabase.from("automations").update({ last_run_at: new Date().toISOString() }).eq("id", id);
  refresh(); return { ok: true, message: `${a.name}: ${res}.` };
}

async function fireTriggers(c: Ctx, type: string, value?: number) {
  const { data } = await c.supabase.from("automations").select("*").eq("is_enabled", true).eq("trigger_type", type);
  for (const a of data ?? []) {
    if (type === "temperature_above" && !(value != null && a.trigger_value != null && value > a.trigger_value)) continue;
    await execAction(c, a.action_type, `${a.name} (otomatis)`);
    await c.supabase.from("automations").update({ last_run_at: new Date().toISOString() }).eq("id", a.id);
  }
}

export async function createAutomation(fd: FormData): Promise<ActionResult> {
  const c = await requireUser();
  const p = automationSchema.safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  if (p.data.trigger_type === "temperature_above" && p.data.trigger_value == null) return { ok: false, message: "Isi batas suhu.", fieldErrors: { trigger_value: "Isi batas suhu." } };
  const { error } = await c.supabase.from("automations").insert({ user_id: c.user.id, kind: "custom", ...p.data, trigger_value: p.data.trigger_type === "temperature_above" ? p.data.trigger_value : null });
  if (error) return { ok: false, message: "Gagal menyimpan otomatisasi." };
  refresh(); return { ok: true, message: "Otomatisasi disimpan." };
}
export async function setAutomationEnabled(id: string, enabled: boolean): Promise<ActionResult> {
  const c = await requireUser();
  await c.supabase.from("automations").update({ is_enabled: enabled }).eq("id", id);
  refresh(); return { ok: true, message: enabled ? "Otomatisasi diaktifkan." : "Otomatisasi dimatikan." };
}
export async function deleteAutomation(id: string): Promise<ActionResult> {
  const c = await requireUser();
  const { error } = await c.supabase.from("automations").delete().eq("id", id).eq("kind", "custom");
  if (error) return { ok: false, message: "Gagal menghapus." };
  refresh(); return { ok: true, message: "Otomatisasi dihapus." };
}

/* ---------- Perangkat ---------- */
export async function addDevice(fd: FormData): Promise<ActionResult> {
  const c = await requireUser();
  const p = deviceSchema.safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  const sim = p.data.is_simulated === "true";
  const { error } = await c.supabase.from("devices").insert({
    user_id: c.user.id, name: p.data.name, type: p.data.type, room_id: p.data.room_id || null,
    is_simulated: sim, is_online: sim, state: defaultState(p.data.type), last_seen: sim ? new Date().toISOString() : null,
  });
  if (error) return { ok: false, message: "Gagal menambah perangkat." };
  await log(c, "device", `Perangkat "${p.data.name}" ditambahkan${sim ? " (simulasi)" : ", menunggu hub fisik"}.`, sim ? "simulation" : "user");
  refresh(); return { ok: true, message: sim ? "Perangkat simulasi ditambahkan." : "Perangkat ditambahkan. Status: menunggu hub fisik." };
}
export async function deleteDevice(id: string): Promise<ActionResult> {
  const c = await requireUser();
  const { error } = await c.supabase.from("devices").delete().eq("id", id);
  if (error) return { ok: false, message: "Gagal menghapus perangkat." };
  refresh(); return { ok: true, message: "Perangkat dihapus." };
}
export async function setSwitch(id: string, on: boolean): Promise<ActionResult> {
  const c = await requireUser();
  const { data: d } = await c.supabase.from("devices").select("*").eq("id", id).single();
  if (!d || d.type !== "smart_switch") return { ok: false, message: "Perangkat tidak ditemukan." };
  if (!d.is_simulated && !d.is_online) return { ok: false, message: "Perangkat belum terhubung ke hub fisik." };
  await c.supabase.from("devices").update({ state: { ...d.state, on }, last_seen: new Date().toISOString() }).eq("id", id);
  await log(c, "device", `${d.name} ${on ? "dinyalakan" : "dimatikan"}.`, d.is_simulated ? "simulation" : "device", id);
  if (d.is_simulated) await c.supabase.from("energy_readings").insert({ user_id: c.user.id, device_id: id, watts: on ? d.state.rated_watts ?? 40 : 0, is_simulated: true });
  refresh(); return { ok: true, message: `${d.name} ${on ? "menyala" : "mati"}.` };
}
export async function setCamRecording(id: string, on: boolean): Promise<ActionResult> {
  const c = await requireUser();
  const { data: d } = await c.supabase.from("devices").select("*").eq("id", id).single();
  if (!d || d.type !== "cam") return { ok: false, message: "Perangkat tidak ditemukan." };
  if (!d.is_simulated && !d.is_online) return { ok: false, message: "Kamera belum terhubung." };
  await c.supabase.from("devices").update({ state: { ...d.state, recording: on } }).eq("id", id);
  await log(c, "security", `${d.name}: perekaman ${on ? "dimulai" : "dihentikan"}.`, d.is_simulated ? "simulation" : "device", id);
  refresh(); return { ok: true, message: `Perekaman ${on ? "dimulai" : "dihentikan"}.` };
}

/** Memperbarui pembacaan seluruh perangkat simulasi. Hanya menyentuh perangkat berlabel simulasi. */
export async function simulateTick(): Promise<ActionResult> {
  const c = await requireUser();
  const devs = (await myDevices(c)).filter((d) => d.is_simulated);
  if (!devs.length) return { ok: false, message: "Tidak ada perangkat simulasi. Aktifkan Simulation Mode dulu." };
  const now = new Date().toISOString(); let temp: number | undefined;
  for (const d of devs) {
    let state = d.state;
    if (d.type === "temperature_sensor") { temp = r1(rand(25, 32)); state = { temperature_c: temp, humidity: Math.round(rand(55, 80)) }; }
    if (d.type === "smart_switch" && d.state.on) await c.supabase.from("energy_readings").insert({ user_id: c.user.id, device_id: d.id, watts: r1((d.state.rated_watts ?? 40) * rand(0.9, 1.08)), is_simulated: true });
    await c.supabase.from("devices").update({ state, last_seen: now, is_online: true }).eq("id", d.id);
  }
  await log(c, "device", "Pembacaan simulasi diperbarui.", "simulation");
  if (temp != null) await fireTriggers(c, "temperature_above", temp);
  refresh(); return { ok: true, message: "Pembacaan simulasi diperbarui." };
}

/** Memicu kejadian keamanan simulasi (gerakan / pintu terbuka). */
export async function simulateSecurityEvent(kind: "motion" | "door_open"): Promise<ActionResult> {
  const c = await requireUser();
  const type = kind === "motion" ? "motion_sensor" : "door_sensor";
  const dev = (await myDevices(c)).find((d) => d.type === type && d.is_simulated);
  if (!dev) return { ok: false, message: `Belum ada ${kind === "motion" ? "Sensor Gerak" : "Sensor Pintu"} simulasi.` };
  const { data: prof } = await c.supabase.from("profiles").select("security_armed").eq("id", c.user.id).single();
  const armed = !!prof?.security_armed;
  const msg = kind === "motion" ? "Gerakan terdeteksi" : "Pintu terbuka";
  await c.supabase.from("devices").update({ state: kind === "motion" ? { motion: true } : { open: true }, last_seen: new Date().toISOString() }).eq("id", dev.id);
  await log(c, "security", `${msg} oleh ${dev.name} (simulasi).`, "simulation", dev.id);
  if (armed) await notify(c, `${msg} saat siaga`, `${dev.name} (simulasi) mencatat kejadian ini ketika keamanan siaga.`, "critical");
  await fireTriggers(c, kind);
  refresh(); return { ok: true, message: `${msg} (simulasi).` };
}
export async function clearSecurityEvents(): Promise<ActionResult> {
  const c = await requireUser();
  for (const d of (await myDevices(c)).filter((d) => d.type === "motion_sensor" || d.type === "door_sensor"))
    await c.supabase.from("devices").update({ state: d.type === "motion_sensor" ? { motion: false } : { open: false } }).eq("id", d.id);
  refresh(); return { ok: true, message: "Status sensor direset." };
}
export async function setArmed(armed: boolean): Promise<ActionResult> {
  const c = await requireUser();
  await c.supabase.from("profiles").update({ security_armed: armed }).eq("id", c.user.id);
  await log(c, "security", `Keamanan ${armed ? "disiagakan" : "dinonaktifkan"}.`, "user");
  refresh(); return { ok: true, message: armed ? "Keamanan siaga." : "Keamanan dinonaktifkan." };
}

/* ---------- Ruangan ---------- */
export async function addRoom(fd: FormData): Promise<ActionResult> {
  const c = await requireUser();
  const p = z.object({ name: z.string().trim().min(1, "Isi nama ruangan.").max(60) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  const { error } = await c.supabase.from("rooms").insert({ user_id: c.user.id, name: p.data.name });
  if (error) return { ok: false, message: error.code === "23505" ? "Nama ruangan sudah ada." : "Gagal menambah ruangan." };
  refresh(); return { ok: true, message: "Ruangan ditambahkan." };
}
export async function renameRoom(fd: FormData): Promise<ActionResult> {
  const c = await requireUser();
  const p = z.object({ id: z.string().uuid(), name: z.string().trim().min(1, "Isi nama ruangan.").max(60) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  const { error } = await c.supabase.from("rooms").update({ name: p.data.name }).eq("id", p.data.id);
  if (error) return { ok: false, message: error.code === "23505" ? "Nama ruangan sudah ada." : "Gagal mengubah nama." };
  refresh(); return { ok: true, message: "Nama ruangan diperbarui." };
}
export async function deleteRoom(id: string): Promise<ActionResult> {
  const c = await requireUser();
  const { error } = await c.supabase.from("rooms").delete().eq("id", id);
  if (error) return { ok: false, message: "Gagal menghapus ruangan." };
  refresh(); return { ok: true, message: "Ruangan dihapus. Perangkatnya tidak terhapus." };
}
export async function moveDevice(fd: FormData): Promise<ActionResult> {
  const c = await requireUser();
  const p = z.object({ id: z.string().uuid(), room_id: z.string().uuid().optional().or(z.literal("")) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  await c.supabase.from("devices").update({ room_id: p.data.room_id || null }).eq("id", p.data.id);
  refresh(); return { ok: true, message: "Perangkat dipindahkan." };
}

/* ---------- Notifikasi & profil ---------- */
export async function markRead(id: string): Promise<ActionResult> {
  const c = await requireUser();
  await c.supabase.from("notifications").update({ is_read: true }).eq("id", id);
  refresh(); return { ok: true, message: "Ditandai sudah dibaca." };
}
export async function markAllRead(): Promise<ActionResult> {
  const c = await requireUser();
  await c.supabase.from("notifications").update({ is_read: true }).eq("is_read", false);
  refresh(); return { ok: true, message: "Semua notifikasi ditandai sudah dibaca." };
}
export async function deleteNotification(id: string): Promise<ActionResult> {
  const c = await requireUser();
  await c.supabase.from("notifications").delete().eq("id", id);
  refresh(); return { ok: true, message: "Notifikasi dihapus." };
}
export async function updateProfile(fd: FormData): Promise<ActionResult> {
  const c = await requireUser();
  const p = z.object({ full_name: z.string().trim().min(2, "Nama minimal 2 karakter.").max(120), phone: z.string().trim().regex(/^[0-9+][0-9 -]{6,18}$/, "Nomor telepon tidak valid.").optional().or(z.literal("")) }).safeParse(Object.fromEntries(fd));
  if (!p.success) return zodFail(p.error);
  const { error } = await c.supabase.from("profiles").update({ full_name: p.data.full_name, phone: p.data.phone || null }).eq("id", c.user.id);
  if (error) return { ok: false, message: "Profil gagal disimpan." };
  refresh(); return { ok: true, message: "Profil disimpan." };
}

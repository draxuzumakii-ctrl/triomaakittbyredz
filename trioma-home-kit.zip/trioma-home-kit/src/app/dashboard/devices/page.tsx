import { requireUser } from "@/lib/auth";
import { PageHeader } from "@/components/ui/bits";
import { DeviceCard } from "@/components/dash/device-card";
import { NoDevices } from "@/components/dash/sim-prompt";
import { ActionButton, ActionForm, Field } from "@/components/ui/action-form";
import { addDevice, simulateTick, resetSimulation } from "../actions";
import { deviceLabel } from "@/lib/format";
import type { Device, Room } from "@/lib/types";
export const metadata = { title: "Perangkat" };

export default async function DevicesPage() {
  const { supabase } = await requireUser();
  const [{ data: d }, { data: r }] = await Promise.all([supabase.from("devices").select("*").order("created_at"), supabase.from("rooms").select("id,name").order("name")]);
  const devices = (d ?? []) as Device[]; const rooms = (r ?? []) as Room[];
  const hasSim = devices.some((x) => x.is_simulated);
  return (
    <>
      <PageHeader title="Perangkat" sub="Motion Sensor, Door Sensor, Temperature Sensor, Smart Switch, dan TRIOMA Cam."
        right={hasSim && <div className="flex gap-2"><ActionButton action={simulateTick} className="btn btn-glass btn-sm">Perbarui pembacaan simulasi</ActionButton><ActionButton action={resetSimulation} confirm="Hapus semua perangkat simulasi?" className="btn btn-danger btn-sm">Hapus simulasi</ActionButton></div>} />
      {devices.length === 0 ? <NoDevices /> : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{devices.map((x) => <DeviceCard key={x.id} d={x} room={rooms.find((r) => r.id === x.room_id)?.name} />)}</div>
      )}
      <section className="glass mt-8 p-6">
        <h2 className="font-medium">Tambah perangkat</h2>
        <p className="mt-1 text-sm text-silver/80">Perangkat fisik berstatus &quot;Belum terhubung&quot; sampai integrasi hub tersedia.</p>
        <ActionForm action={addDevice} resetOnSuccess className="mt-5 grid gap-4 md:grid-cols-2" submitLabel="Tambah perangkat" submitClass="btn btn-primary md:col-span-2 md:w-fit">
          <Field name="name" label="Nama"><input id="name" name="name" className="field" placeholder="Sensor Pintu Belakang" /></Field>
          <Field name="type" label="Jenis"><select id="type" name="type" className="field">{Object.entries(deviceLabel).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
          <Field name="room_id" label="Ruangan"><select id="room_id" name="room_id" className="field"><option value="">Tanpa ruangan</option>{rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>
          <Field name="is_simulated" label="Sumber"><select id="is_simulated" name="is_simulated" className="field"><option value="true">Simulasi</option><option value="false">Perangkat fisik (menunggu hub)</option></select></Field>
        </ActionForm>
      </section>
    </>
  );
}

import { requireUser } from "@/lib/auth";
import { EmptyState, PageHeader } from "@/components/ui/bits";
import { ActionButton } from "@/components/ui/action-form";
import { deleteNotification, markAllRead, markRead } from "../actions";
import { timeAgo, cn } from "@/lib/format";
import type { Notification } from "@/lib/types";
export const metadata = { title: "Notifikasi" };

export default async function NotificationsPage() {
  const { supabase } = await requireUser();
  const { data } = await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(60);
  const items = (data ?? []) as Notification[];
  const unread = items.filter((n) => !n.is_read).length;
  const dot = { info: "bg-electric", success: "bg-[var(--ok)]", warning: "bg-[var(--warn)]", critical: "bg-[var(--bad)]" };
  return (
    <>
      <PageHeader title="Notifikasi" sub={unread ? `${unread} belum dibaca.` : "Semua sudah dibaca."} right={unread > 0 && <ActionButton action={markAllRead}>Tandai semua dibaca</ActionButton>} />
      {items.length === 0 ? <EmptyState title="Belum ada notifikasi" body="Peringatan keamanan, pembaruan pesanan, dan pesan sistem akan muncul di sini secara langsung." /> : (
        <ul className="space-y-2">
          {items.map((n) => (
            <li key={n.id} className={cn("glass flex items-start gap-3 p-4", n.is_read && "opacity-70")}>
              <span className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", dot[n.level])} />
              <div className="min-w-0 flex-1"><p className="font-medium">{n.title}</p><p className="mt-0.5 break-words text-sm text-silver">{n.body}</p><p className="mt-1 text-xs text-silver/60">{timeAgo(n.created_at)}</p></div>
              <div className="flex gap-2">{!n.is_read && <ActionButton action={markRead.bind(null, n.id)}>Baca</ActionButton>}<ActionButton action={deleteNotification.bind(null, n.id)} ariaLabel="Hapus notifikasi">Hapus</ActionButton></div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

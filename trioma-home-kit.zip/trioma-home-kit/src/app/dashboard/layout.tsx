import { requireUser } from "@/lib/auth";
import { DashNav } from "@/components/dash/dash-nav";
import { RealtimeBridge } from "@/components/dash/realtime";

export default async function DashLayout({ children }: { children: React.ReactNode }) {
  const { supabase, user, profile } = await requireUser();
  const { count } = await supabase.from("notifications").select("id", { count: "exact", head: true }).eq("is_read", false);
  return (
    <div className="min-h-dvh">
      <DashNav unread={count ?? 0} isAdmin={profile.role !== "user"} name={profile.full_name} />
      <RealtimeBridge userId={user.id} />
      <main className="px-4 pb-32 pt-8 lg:ml-[17rem] lg:pr-8 lg:pb-12"><div className="mx-auto max-w-5xl">{children}</div></main>
    </div>
  );
}

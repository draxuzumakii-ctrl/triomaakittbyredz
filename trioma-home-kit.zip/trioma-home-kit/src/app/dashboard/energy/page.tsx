import { requireUser } from "@/lib/auth";
import { PageHeader, SimBadge, EmptyState } from "@/components/ui/bits";
import { NoDevices } from "@/components/dash/sim-prompt";
import { ActionButton } from "@/components/ui/action-form";
import { simulateTick } from "../actions";
import type { Device } from "@/lib/types";
export const metadata = { title: "Energi" };

export default async function EnergyPage() {
  const { supabase } = await requireUser();
  const [{ data: d }, { data: e }] = await Promise.all([
    supabase.from("devices").select("*").eq("type", "smart_switch"),
    supabase.from("energy_readings").select("watts,is_simulated,recorded_at").order("recorded_at", { ascending: false }).limit(24),
  ]);
  const switches = (d ?? []) as Device[];
  const readings = ((e ?? []) as { watts: number; is_simulated: boolean; recorded_at: string }[]).reverse();
  const now = switches.reduce((s, x) => s + (x.state.on && x.is_online ? Number(x.state.rated_watts ?? 0) : 0), 0);
  const max = Math.max(1, ...readings.map((r) => Number(r.watts)));
  const simulated = switches.some((x) => x.is_simulated) || readings.some((r) => r.is_simulated);
  return (
    <>
      <PageHeader title="Energi" sub="Beban listrik per Smart Switch." right={simulated && <SimBadge />} />
      {switches.length === 0 ? <NoDevices /> : (
        <>
          <div className="glass p-6">
            <p className="text-sm text-silver">Beban saat ini</p>
            <p className="mt-1 text-5xl font-semibold tracking-display">{now} <span className="text-xl text-silver">W</span></p>
            <p className="mt-2 text-xs text-silver/60">Dihitung dari daya terpasang Smart Switch yang menyala{simulated ? " (nilai simulasi)" : ""}.</p>
          </div>
          <section className="glass mt-4 p-6">
            <div className="flex items-center justify-between"><h2 className="font-medium">Pembacaan terakhir</h2>{switches.some((x) => x.is_simulated) && <ActionButton action={simulateTick}>Ambil pembacaan simulasi</ActionButton>}</div>
            {readings.length === 0 ? <p className="mt-4 text-sm text-silver">Belum ada pembacaan. Nyalakan Smart Switch lalu ambil pembacaan.</p> : (
              <div className="mt-6 flex h-40 items-end gap-1.5" role="img" aria-label="Grafik batang beban listrik">
                {readings.map((r, i) => <div key={i} title={`${r.watts} W`} className="flex-1 rounded-t-md bg-electric/70" style={{ height: `${Math.max(4, (Number(r.watts) / max) * 100)}%` }} />)}
              </div>
            )}
          </section>
          <h2 className="mb-3 mt-8 text-lg font-medium">Per perangkat</h2>
          <ul className="divide-y divide-white/[.08] text-sm">
            {switches.map((x) => <li key={x.id} className="flex items-center justify-between py-3"><span className="flex items-center gap-2">{x.name}{x.is_simulated && <SimBadge />}</span><span className="text-silver">{x.state.on ? `${x.state.rated_watts ?? 0} W` : "Mati"}</span></li>)}
          </ul>
        </>
      )}
    </>
  );
}

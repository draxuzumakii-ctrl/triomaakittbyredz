import { requireUser } from "@/lib/auth";
import { PageHeader, EmptyState, SimBadge } from "@/components/ui/bits";
import { ActionButton, ActionForm, Field, ToggleSwitch } from "@/components/ui/action-form";
import { createAutomation, deleteAutomation, runAutomation, runMode, setAutomationEnabled } from "../actions";
import { timeAgo } from "@/lib/format";
import type { ActivityLog, Automation } from "@/lib/types";
export const metadata = { title: "Otomatisasi" };

const trig: Record<string, string> = { manual: "Dijalankan manual", motion: "Saat gerakan terdeteksi", door_open: "Saat pintu terbuka", temperature_above: "Saat suhu melebihi batas" };
const act: Record<string, string> = { switches_off: "Matikan semua Smart Switch", switches_on: "Nyalakan semua Smart Switch", notify: "Kirim notifikasi", arm_security: "Siagakan keamanan", disarm_security: "Nonaktifkan keamanan" };

export default async function AutomationPage() {
  const { supabase, profile } = await requireUser();
  const [{ data: a }, { data: h }] = await Promise.all([
    supabase.from("automations").select("*").order("created_at"),
    supabase.from("activity_logs").select("*").eq("category", "automation").order("created_at", { ascending: false }).limit(10),
  ]);
  const list = (a ?? []) as Automation[]; const hist = (h ?? []) as ActivityLog[];
  const custom = list.filter((x) => x.kind === "custom");
  return (
    <>
      <PageHeader title="Otomatisasi" sub="Satu ketukan untuk rutinitas rumah." />
      <div className="grid gap-4 md:grid-cols-2">
        {([["pergi", "Mode Pergi", "Matikan Smart Switch dan siagakan keamanan."], ["pulang", "Mode Pulang", "Nyalakan Smart Switch dan nonaktifkan keamanan."]] as const).map(([k, t, d]) => (
          <section key={k} className={`glass p-6 ${profile.home_mode === k ? "shadow-[inset_0_0_0_1px_rgba(106,159,255,.5)]" : ""}`}>
            <h2 className="text-xl font-medium tracking-tight">{t}</h2>
            <p className="mt-1 text-sm text-silver">{d}</p>
            <p className="mt-3 text-xs text-silver/60">{profile.home_mode === k ? "Mode aktif saat ini" : list.find((x) => x.kind === k)?.last_run_at ? `Terakhir dijalankan ${timeAgo(list.find((x) => x.kind === k)!.last_run_at!)}` : "Belum pernah dijalankan"}</p>
            <ActionButton action={runMode.bind(null, k)} className="btn btn-primary mt-5">Jalankan {t}</ActionButton>
          </section>
        ))}
      </div>

      <h2 className="mb-3 mt-10 text-lg font-medium">Otomatisasi buatan Anda</h2>
      {custom.length === 0 ? <EmptyState title="Belum ada otomatisasi kustom" body="Buat aturan, misalnya: saat pintu terbuka, kirim notifikasi." /> : (
        <ul className="space-y-3">
          {custom.map((x) => (
            <li key={x.id} className="glass flex flex-wrap items-center justify-between gap-4 p-4">
              <div><p className="font-medium">{x.name}</p><p className="text-xs text-silver/70">{trig[x.trigger_type]}{x.trigger_value != null && ` (${x.trigger_value}°C)`}, {act[x.action_type]}</p></div>
              <div className="flex items-center gap-3">
                <ActionButton action={runAutomation.bind(null, x.id)} className="btn btn-glass btn-sm">Jalankan</ActionButton>
                <ToggleSwitch checked={x.is_enabled} label={`Aktifkan ${x.name}`} action={setAutomationEnabled.bind(null, x.id)} />
                <ActionButton action={deleteAutomation.bind(null, x.id)} confirm={`Hapus ${x.name}?`} className="btn btn-danger btn-sm">Hapus</ActionButton>
              </div>
            </li>
          ))}
        </ul>
      )}

      <section className="glass mt-6 p-6">
        <h2 className="font-medium">Buat otomatisasi</h2>
        <ActionForm action={createAutomation} resetOnSuccess className="mt-4 grid gap-4 md:grid-cols-2" submitLabel="Simpan otomatisasi" submitClass="btn btn-primary md:col-span-2 md:w-fit">
          <Field name="name" label="Nama"><input id="name" name="name" className="field" placeholder="Pintu terbuka, beri tahu saya" /></Field>
          <Field name="trigger_type" label="Pemicu"><select id="trigger_type" name="trigger_type" className="field">{Object.entries(trig).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
          <Field name="trigger_value" label="Batas suhu (°C, hanya untuk pemicu suhu)"><input id="trigger_value" name="trigger_value" type="number" step="0.1" className="field" /></Field>
          <Field name="action_type" label="Tindakan"><select id="action_type" name="action_type" className="field">{Object.entries(act).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
        </ActionForm>
        <p className="mt-3 flex items-center gap-2 text-xs text-silver/60"><SimBadge />Pemicu gerakan, pintu, dan suhu saat ini hanya dapat dipicu dari Simulation Mode sampai hub fisik tersedia.</p>
      </section>

      <h2 className="mb-3 mt-10 text-lg font-medium">Riwayat otomatisasi</h2>
      {hist.length === 0 ? <p className="text-sm text-silver">Belum ada riwayat.</p> : (
        <ul className="divide-y divide-white/[.08] text-sm">{hist.map((x) => <li key={x.id} className="flex items-center justify-between gap-3 py-3"><span className="flex items-center gap-2">{x.message}{x.source === "simulation" && <SimBadge />}</span><span className="shrink-0 text-xs text-silver/60">{timeAgo(x.created_at)}</span></li>)}</ul>
      )}
    </>
  );
}

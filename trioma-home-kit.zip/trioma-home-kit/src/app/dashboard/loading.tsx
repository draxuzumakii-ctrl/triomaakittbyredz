import { Skeleton } from "@/components/ui/bits";
export default function Loading() {
  return (
    <div className="space-y-5" aria-busy="true" aria-label="Memuat">
      <Skeleton className="h-10 w-64" />
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-24" />)}</div>
      <Skeleton className="h-64" />
    </div>
  );
}

import { requireUser } from "@/lib/auth";
import { PageHeader } from "@/components/ui/bits";
import { ActionForm, Field, ActionButton } from "@/components/ui/action-form";
import { updateProfile, resetSimulation } from "../actions";
import { logout } from "@/app/auth/actions";
export const metadata = { title: "Pengaturan" };

export default async function SettingsPage() {
  const { profile, user } = await requireUser();
  return (
    <>
      <PageHeader title="Pengaturan akun" />
      <section className="glass max-w-xl p-6">
        <ActionForm action={updateProfile} className="space-y-4" submitLabel="Simpan profil">
          <Field name="email" label="Email"><input id="email" className="field" value={user.email ?? ""} readOnly disabled /></Field>
          <Field name="full_name" label="Nama lengkap"><input id="full_name" name="full_name" className="field" defaultValue={profile.full_name} /></Field>
          <Field name="phone" label="Nomor telepon"><input id="phone" name="phone" className="field" defaultValue={profile.phone ?? ""} inputMode="tel" /></Field>
        </ActionForm>
      </section>
      <section className="glass mt-4 max-w-xl p-6">
        <h2 className="font-medium">Data simulasi</h2>
        <p className="mt-1 text-sm text-silver">Hapus semua perangkat yang dibuat oleh Simulation Mode. Perangkat fisik tidak terpengaruh.</p>
        <div className="mt-4"><ActionButton action={resetSimulation} confirm="Hapus semua perangkat simulasi?" className="btn btn-danger btn-sm">Hapus perangkat simulasi</ActionButton></div>
      </section>
      <form action={logout} className="mt-6"><button className="btn btn-glass">Keluar</button></form>
    </>
  );
}

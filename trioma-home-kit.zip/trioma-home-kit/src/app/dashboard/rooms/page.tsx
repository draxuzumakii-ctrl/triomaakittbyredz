import { requireUser } from "@/lib/auth";
import { EmptyState, PageHeader } from "@/components/ui/bits";
import { ActionButton, ActionForm, Field } from "@/components/ui/action-form";
import { addRoom, deleteRoom, renameRoom, moveDevice } from "../actions";
import type { Device, Room } from "@/lib/types";
export const metadata = { title: "Ruangan" };

export default async function RoomsPage() {
  const { supabase } = await requireUser();
  const [{ data: r }, { data: d }] = await Promise.all([supabase.from("rooms").select("id,name").order("name"), supabase.from("devices").select("id,name,room_id")]);
  const rooms = (r ?? []) as Room[]; const devices = (d ?? []) as Pick<Device, "id" | "name" | "room_id">[];
  const loose = devices.filter((x) => !x.room_id);
  return (
    <>
      <PageHeader title="Ruangan" sub="Kelompokkan perangkat berdasarkan ruangan." />
      <section className="glass mb-6 p-5">
        <ActionForm action={addRoom} resetOnSuccess className="flex flex-wrap items-end gap-3" submitLabel="Tambah ruangan">
          <div className="min-w-[200px] flex-1"><Field name="name" label="Nama ruangan baru"><input id="name" name="name" className="field" placeholder="Kamar Utama" /></Field></div>
        </ActionForm>
      </section>
      {rooms.length === 0 ? <EmptyState title="Belum ada ruangan" body="Tambahkan ruangan pertama Anda, misalnya Ruang Tamu atau Teras." /> : (
        <div className="grid gap-4 md:grid-cols-2">
          {rooms.map((room) => {
            const inRoom = devices.filter((x) => x.room_id === room.id);
            return (
              <section key={room.id} className="glass p-5">
                <ActionForm action={renameRoom} className="flex items-center gap-2" submitLabel="Ubah" submitClass="btn btn-glass btn-sm">
                  <input type="hidden" name="id" value={room.id} />
                  <input name="name" defaultValue={room.name} className="field !min-h-[38px] flex-1" aria-label={`Nama ruangan ${room.name}`} />
                </ActionForm>
                <p className="mt-4 text-xs text-silver/70">{inRoom.length} perangkat</p>
                <ul className="mt-2 divide-y divide-white/[.08] text-sm">{inRoom.map((x) => <li key={x.id} className="py-2">{x.name}</li>)}</ul>
                <div className="mt-4"><ActionButton action={deleteRoom.bind(null, room.id)} confirm={`Hapus ruangan ${room.name}? Perangkat tidak ikut terhapus.`} className="btn btn-danger btn-sm">Hapus ruangan</ActionButton></div>
              </section>
            );
          })}
        </div>
      )}
      {devices.length > 0 && rooms.length > 0 && (
        <section className="glass mt-6 p-5">
          <h2 className="font-medium">Pindahkan perangkat</h2>
          <p className="mt-1 text-sm text-silver/80">{loose.length ? `${loose.length} perangkat belum punya ruangan.` : "Pilih perangkat dan ruangan tujuan."}</p>
          <ActionForm action={moveDevice} className="mt-4 grid gap-3 md:grid-cols-[1fr_1fr_auto] md:items-end" submitLabel="Pindahkan">
            <Field name="id" label="Perangkat"><select id="id" name="id" className="field">{devices.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></Field>
            <Field name="room_id" label="Ke ruangan"><select id="room_id" name="room_id" className="field"><option value="">Tanpa ruangan</option>{rooms.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></Field>
          </ActionForm>
        </section>
      )}
    </>
  );
}

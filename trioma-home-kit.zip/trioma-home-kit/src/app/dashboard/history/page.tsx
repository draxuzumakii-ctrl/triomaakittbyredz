import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { EmptyState, PageHeader, SimBadge } from "@/components/ui/bits";
import { dateTime, cn } from "@/lib/format";
import type { ActivityLog } from "@/lib/types";
export const metadata = { title: "Riwayat" };

const filters = [["", "Semua"], ["device", "Perangkat"], ["security", "Keamanan"], ["automation", "Otomatisasi"], ["order", "Pesanan"]];

export default async function HistoryPage({ searchParams }: { searchParams: Promise<{ k?: string }> }) {
  const { k = "" } = await searchParams;
  const { supabase } = await requireUser();
  let q = supabase.from("activity_logs").select("*").order("created_at", { ascending: false }).limit(100);
  if (filters.some(([v]) => v === k && v)) q = q.eq("category", k);
  const { data } = await q; const logs = (data ?? []) as ActivityLog[];
  return (
    <>
      <PageHeader title="Riwayat aktivitas" sub="100 aktivitas terakhir." />
      <div className="mb-5 flex flex-wrap gap-2">
        {filters.map(([v, l]) => <Link key={v} href={v ? `?k=${v}` : "?"} className={cn("btn btn-sm", k === v ? "btn-primary" : "btn-glass")}>{l}</Link>)}
      </div>
      {logs.length === 0 ? <EmptyState title="Belum ada aktivitas" body="Aktivitas perangkat, keamanan, otomatisasi, dan pesanan akan muncul di sini." /> : (
        <ul className="glass divide-y divide-white/[.08] p-2 text-sm">
          {logs.map((x) => (
            <li key={x.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3">
              <span className="flex items-center gap-2">{x.message}{x.source === "simulation" && <SimBadge />}</span>
              <span className="text-xs text-silver/60">{dateTime(x.created_at)}</span>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

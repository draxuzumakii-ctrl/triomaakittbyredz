import Link from "next/link";
import type { Metadata } from "next";
import { ActionForm, Field } from "@/components/ui/action-form";
import { AuthShell } from "../shell";
import { register } from "../actions";
export const metadata: Metadata = { title: "Daftar" };

export default async function RegisterPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next = "/dashboard" } = await searchParams;
  return (
    <AuthShell title="Buat akun" sub="Gratis. Anda bisa mencoba dashboard dengan Simulation Mode."
      footer={<>Sudah punya akun? <Link href={`/auth/login?next=${encodeURIComponent(next)}`} className="text-electric">Masuk</Link></>}>
      <ActionForm action={register} className="space-y-4" submitLabel="Buat akun" submitClass="btn btn-primary w-full">
        <input type="hidden" name="next" value={next} />
        <Field name="full_name" label="Nama lengkap"><input id="full_name" name="full_name" className="field" autoComplete="name" /></Field>
        <Field name="email" label="Email"><input id="email" name="email" type="email" className="field" autoComplete="email" /></Field>
        <Field name="phone" label="Nomor telepon (opsional)"><input id="phone" name="phone" className="field" inputMode="tel" autoComplete="tel" /></Field>
        <Field name="password" label="Kata sandi (min. 8 karakter)"><input id="password" name="password" type="password" className="field" autoComplete="new-password" /></Field>
      </ActionForm>
    </AuthShell>
  );
}

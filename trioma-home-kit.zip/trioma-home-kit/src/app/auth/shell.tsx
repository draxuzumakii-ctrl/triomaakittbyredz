import { Logo } from "@/components/site/logo";

export function AuthShell({ title, sub, children, footer }: { title: string; sub: string; children: React.ReactNode; footer: React.ReactNode }) {
  return (
    <main className="grid min-h-dvh md:grid-cols-[1fr_1.1fr]">
      <div className="hidden flex-col justify-between border-r border-white/[.08] p-12 md:flex">
        <Logo />
        <div>
          <p className="display text-6xl">One Network.<br />Three Functions.</p>
          <p className="prose-tight mt-6">Otomatisasi, keamanan, dan efisiensi energi dalam satu TRIOMA Home Kit.</p>
        </div>
        <p className="text-xs text-silver/50">TRIOMA Home Kit</p>
      </div>
      <div className="grid place-items-center px-5 py-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 md:hidden"><Logo /></div>
          <h1 className="text-3xl font-semibold tracking-display">{title}</h1>
          <p className="mt-2 text-sm text-silver">{sub}</p>
          <div className="glass mt-8 p-6">{children}</div>
          <div className="mt-5 text-center text-sm text-silver">{footer}</div>
        </div>
      </div>
    </main>
  );
}

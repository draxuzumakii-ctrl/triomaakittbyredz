import Link from "next/link";
import type { Metadata } from "next";
import { ActionForm, Field } from "@/components/ui/action-form";
import { AuthShell } from "../shell";
import { login } from "../actions";
export const metadata: Metadata = { title: "Masuk" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next = "/dashboard" } = await searchParams;
  return (
    <AuthShell title="Masuk" sub="Kelola rumah dan pesanan Anda."
      footer={<>Belum punya akun? <Link href={`/auth/register?next=${encodeURIComponent(next)}`} className="text-electric">Daftar</Link></>}>
      <ActionForm action={login} className="space-y-4" submitLabel="Masuk" submitClass="btn btn-primary w-full">
        <input type="hidden" name="next" value={next} />
        <Field name="email" label="Email"><input id="email" name="email" type="email" className="field" autoComplete="email" /></Field>
        <Field name="password" label="Kata sandi"><input id="password" name="password" type="password" className="field" autoComplete="current-password" /></Field>
      </ActionForm>
    </AuthShell>
  );
}

"use server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { loginSchema, registerSchema, zodFail } from "@/lib/validation";
import type { ActionResult } from "@/lib/types";

/** Hanya izinkan jalur internal untuk mencegah open redirect. */
const safeNext = (n: FormDataEntryValue | null) => (typeof n === "string" && /^\/(?!\/)[\w\-/?=&]*$/.test(n) ? n : "/dashboard");

export async function login(fd: FormData): Promise<ActionResult | void> {
  const parsed = loginSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return zodFail(parsed.error);
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) return { ok: false, message: "Email atau kata sandi salah." };
  redirect(safeNext(fd.get("next")));
}

export async function register(fd: FormData): Promise<ActionResult | void> {
  const parsed = registerSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return zodFail(parsed.error);
  const { email, password, full_name, phone } = parsed.data;
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name, phone: phone ?? "" } } });
  if (error) return { ok: false, message: error.message.toLowerCase().includes("registered") ? "Email ini sudah terdaftar. Silakan masuk." : "Pendaftaran gagal. Periksa data Anda." };
  if (!data.session) return { ok: true, message: "Akun dibuat. Periksa email Anda untuk konfirmasi, lalu masuk." };
  redirect(safeNext(fd.get("next")));
}

export async function logout() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}

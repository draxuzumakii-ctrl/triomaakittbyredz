import type { Metadata, Viewport } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";
import { ToastProvider } from "@/components/ui/toast";
import { LightTracker } from "@/components/light-tracker";

export const metadata: Metadata = {
  title: { default: "TRIOMA Home Kit", template: "%s | TRIOMA Home Kit" },
  description: "TRIOMA Home Kit: satu jaringan, tiga fungsi. Otomatisasi, keamanan, dan efisiensi energi dalam satu ekosistem rumah pintar.",
};
export const viewport: Viewport = { themeColor: "#080A0F", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body>
        <ToastProvider>
          <LightTracker />
          {children}
        </ToastProvider>
      </body>
    </html>
  );
}

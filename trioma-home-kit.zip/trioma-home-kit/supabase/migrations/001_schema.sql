-- TRIOMA Home Kit - skema database, RLS, dan fungsi
-- Jalankan di Supabase -> SQL Editor (atau `supabase db push`).

create extension if not exists pgcrypto;

-- ---------- ENUM ----------
create type user_role as enum ('user', 'admin', 'super_admin');
create type order_status as enum ('pending', 'confirmed', 'processing', 'completed', 'cancelled');
create type device_type as enum ('motion_sensor', 'door_sensor', 'temperature_sensor', 'smart_switch', 'cam');
create type log_source as enum ('device', 'simulation', 'user', 'system');
create type product_kind as enum ('package', 'accessory');

-- ---------- PROFILES ----------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '' check (char_length(full_name) <= 120),
  phone text check (phone is null or phone ~ '^[0-9+][0-9 -]{6,18}$'),
  role user_role not null default 'user',
  security_armed boolean not null default false,
  home_mode text not null default 'pulang' check (home_mode in ('pergi', 'pulang')),
  created_at timestamptz not null default now()
);

-- ---------- ROLE HELPERS ----------
create or replace function current_role_name() returns text
language sql stable security definer set search_path = public as
$$ select role::text from profiles where id = auth.uid() $$;

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as
$$ select coalesce(current_role_name() in ('admin', 'super_admin'), false) $$;

create or replace function is_super_admin() returns boolean
language sql stable security definer set search_path = public as
$$ select coalesce(current_role_name() = 'super_admin', false) $$;

-- Hanya Super Admin yang boleh mengubah role (SQL Editor / service role diizinkan untuk bootstrap).
create or replace function guard_role_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null and not is_super_admin() then
    raise exception 'Hanya Super Admin yang dapat mengubah role.';
  end if;
  return new;
end $$;
create trigger profiles_guard_role before update on profiles
  for each row execute function guard_role_change();

create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, full_name, phone)
  values (new.id,
          coalesce(left(new.raw_user_meta_data ->> 'full_name', 120), ''),
          nullif(new.raw_user_meta_data ->> 'phone', ''))
  on conflict (id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- ---------- PRODUK ----------
create table products (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9-]+$'),
  name text not null,
  kind product_kind not null default 'package',
  focus text not null default '',
  tagline text not null default '',
  description text not null default '',
  price_idr integer not null check (price_idr >= 0),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  specs jsonb not null default '[]'::jsonb,   -- [{ "label": "...", "value": "..." }]
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- HPP dipisah agar tidak pernah terbaca oleh publik (RLS tidak bisa menyembunyikan kolom).
create table product_costs (
  product_id uuid primary key references products(id) on delete cascade,
  hpp_idr integer not null check (hpp_idr >= 0)
);

create table product_packages (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  item_name text not null,
  quantity integer not null default 1 check (quantity > 0),
  notes text not null default '',
  sort_order integer not null default 0
);
create index on product_packages (product_id);

-- ---------- PESANAN ----------
create table orders (
  id uuid primary key default gen_random_uuid(),
  code text not null unique default ('TRM-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6))),
  user_id uuid not null references profiles(id) on delete restrict,
  customer_name text not null check (char_length(customer_name) between 2 and 120),
  phone text not null check (phone ~ '^[0-9+][0-9 -]{6,18}$'),
  address text not null check (char_length(address) between 8 and 500),
  notes text not null default '' check (char_length(notes) <= 500),
  status order_status not null default 'pending',
  total_idr integer not null check (total_idr >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on orders (user_id, created_at desc);
create index on orders (status);

create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid not null references products(id) on delete restrict,
  quantity integer not null check (quantity > 0),
  unit_price_idr integer not null check (unit_price_idr >= 0)
);
create index on order_items (order_id);

-- ---------- RUMAH, PERANGKAT, OTOMATISASI ----------
create table rooms (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 60),
  created_at timestamptz not null default now(),
  unique (user_id, name)
);

create table devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  room_id uuid references rooms(id) on delete set null,
  name text not null check (char_length(name) between 1 and 80),
  type device_type not null,
  is_simulated boolean not null default true,
  is_online boolean not null default false,
  state jsonb not null default '{}'::jsonb,
  last_seen timestamptz,
  created_at timestamptz not null default now()
);
create index on devices (user_id);

create table automations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  kind text not null default 'custom' check (kind in ('pergi', 'pulang', 'custom')),
  trigger_type text not null default 'manual' check (trigger_type in ('manual', 'motion', 'door_open', 'temperature_above')),
  trigger_value numeric,
  action_type text not null default 'switches_off' check (action_type in ('switches_off', 'switches_on', 'notify', 'arm_security', 'disarm_security')),
  is_enabled boolean not null default true,
  last_run_at timestamptz,
  created_at timestamptz not null default now()
);
create index on automations (user_id);

create table activity_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  device_id uuid references devices(id) on delete set null,
  category text not null default 'system' check (category in ('system', 'device', 'security', 'automation', 'energy', 'order', 'admin')),
  message text not null,
  source log_source not null default 'system',
  created_at timestamptz not null default now()
);
create index on activity_logs (user_id, created_at desc);

create table energy_readings (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  device_id uuid not null references devices(id) on delete cascade,
  watts numeric not null check (watts >= 0),
  is_simulated boolean not null default true,
  recorded_at timestamptz not null default now()
);
create index on energy_readings (user_id, recorded_at desc);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  title text not null,
  body text not null default '',
  level text not null default 'info' check (level in ('info', 'success', 'warning', 'critical')),
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index on notifications (user_id, is_read, created_at desc);

create table system_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

-- ---------- FUNGSI PESANAN (atomik, harga selalu dari database) ----------
create or replace function place_order(
  p_product uuid, p_qty integer, p_name text, p_phone text, p_address text, p_notes text
) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_price integer; v_order uuid; v_code text;
begin
  if auth.uid() is null then raise exception 'Silakan masuk terlebih dahulu.'; end if;
  if p_qty is null or p_qty < 1 or p_qty > 50 then raise exception 'Jumlah pesanan harus 1 sampai 50.'; end if;

  update products set stock = stock - p_qty, updated_at = now()
   where id = p_product and is_active and stock >= p_qty
   returning price_idr into v_price;
  if not found then raise exception 'Stok tidak mencukupi atau produk tidak tersedia.'; end if;

  insert into orders (user_id, customer_name, phone, address, notes, total_idr)
  values (auth.uid(), trim(p_name), trim(p_phone), trim(p_address), coalesce(trim(p_notes), ''), v_price * p_qty)
  returning id, code into v_order, v_code;

  insert into order_items (order_id, product_id, quantity, unit_price_idr)
  values (v_order, p_product, p_qty, v_price);

  insert into notifications (user_id, title, body, level)
  values (auth.uid(), 'Pesanan diterima', 'Pesanan ' || v_code || ' menunggu konfirmasi admin.', 'info');

  insert into notifications (user_id, title, body, level)
  select id, 'Pesanan baru', 'Pesanan ' || v_code || ' dari ' || trim(p_name) || '.', 'info'
    from profiles where role in ('admin', 'super_admin');

  insert into activity_logs (user_id, category, message, source)
  values (auth.uid(), 'order', 'Pesanan ' || v_code || ' dibuat.', 'user');

  return v_order;
end $$;

-- Saat status berubah: beri tahu pengguna; kembalikan stok jika dibatalkan.
create or replace function on_order_status_change() returns trigger
language plpgsql security definer set search_path = public as $$
declare labels jsonb := '{"pending":"Menunggu","confirmed":"Dikonfirmasi","processing":"Diproses","completed":"Selesai","cancelled":"Dibatalkan"}';
begin
  if new.status is distinct from old.status then
    new.updated_at = now();
    insert into notifications (user_id, title, body, level)
    values (new.user_id, 'Status pesanan diperbarui',
            'Pesanan ' || new.code || ' kini ' || (labels ->> new.status::text) || '.',
            case new.status when 'cancelled' then 'warning' when 'completed' then 'success' else 'info' end);
    if new.status = 'cancelled' and old.status <> 'cancelled' then
      update products p set stock = p.stock + oi.quantity
        from order_items oi where oi.order_id = new.id and oi.product_id = p.id;
    end if;
  end if;
  return new;
end $$;
create trigger orders_status_change before update on orders
  for each row execute function on_order_status_change();

-- ---------- ROW LEVEL SECURITY ----------
alter table profiles enable row level security;
alter table products enable row level security;
alter table product_costs enable row level security;
alter table product_packages enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table rooms enable row level security;
alter table devices enable row level security;
alter table automations enable row level security;
alter table activity_logs enable row level security;
alter table energy_readings enable row level security;
alter table notifications enable row level security;
alter table system_settings enable row level security;

-- profiles
create policy "profil: baca milik sendiri / admin" on profiles for select using (id = auth.uid() or is_admin());
create policy "profil: ubah milik sendiri" on profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "profil: super admin ubah semua" on profiles for update using (is_super_admin());

-- products (publik hanya produk aktif)
create policy "produk: publik baca aktif" on products for select using (is_active or is_admin());
create policy "produk: admin tulis" on products for all using (is_admin()) with check (is_admin());
create policy "hpp: admin saja" on product_costs for all using (is_admin()) with check (is_admin());
create policy "isi paket: publik baca" on product_packages for select using (
  exists (select 1 from products p where p.id = product_id and (p.is_active or is_admin())));
create policy "isi paket: admin tulis" on product_packages for all using (is_admin()) with check (is_admin());

-- orders (pembuatan hanya lewat place_order)
create policy "pesanan: baca milik sendiri / admin" on orders for select using (user_id = auth.uid() or is_admin());
create policy "pesanan: admin ubah" on orders for update using (is_admin()) with check (is_admin());
create policy "item pesanan: baca" on order_items for select using (
  exists (select 1 from orders o where o.id = order_id and (o.user_id = auth.uid() or is_admin())));

-- data rumah milik pengguna
create policy "ruangan: milik sendiri" on rooms for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "ruangan: admin baca" on rooms for select using (is_admin());
create policy "perangkat: milik sendiri" on devices for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "perangkat: admin baca" on devices for select using (is_admin());
create policy "otomatisasi: milik sendiri" on automations for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "log: baca milik sendiri / admin" on activity_logs for select using (user_id = auth.uid() or is_admin());
create policy "log: tulis milik sendiri" on activity_logs for insert with check (user_id = auth.uid() or (user_id is null and is_admin()));
create policy "energi: milik sendiri" on energy_readings for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "notifikasi: baca milik sendiri" on notifications for select using (user_id = auth.uid());
create policy "notifikasi: ubah milik sendiri" on notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "notifikasi: hapus milik sendiri" on notifications for delete using (user_id = auth.uid());

-- system_settings: kunci publik dapat dibaca semua, selebihnya admin
create policy "setelan: publik baca" on system_settings for select using (key in ('site', 'announcement') or is_admin());
create policy "setelan: admin tulis" on system_settings for all using (is_admin()) with check (is_admin());

-- ---------- REALTIME ----------
alter publication supabase_realtime add table notifications, devices, activity_logs;

-- ---------- STORAGE (foto produk) ----------
insert into storage.buckets (id, name, public) values ('product-images', 'product-images', true)
  on conflict (id) do nothing;
create policy "foto produk: publik baca" on storage.objects for select using (bucket_id = 'product-images');
create policy "foto produk: admin unggah" on storage.objects for insert with check (bucket_id = 'product-images' and is_admin());
create policy "foto produk: admin ubah" on storage.objects for update using (bucket_id = 'product-images' and is_admin());
create policy "foto produk: admin hapus" on storage.objects for delete using (bucket_id = 'product-images' and is_admin());

-- ---------- DATA AWAL (katalog TRIOMA) ----------
-- Harga dan HPP sesuai spesifikasi proyek. Isi paket, spesifikasi, dan stok awal
-- adalah titik awal: periksa dan ubah lewat Admin -> Produk / Paket.
insert into products (slug, name, kind, focus, tagline, description, price_idr, stock, sort_order, specs) values
('paket-teras', 'Paket TERAS', 'package', 'Otomatisasi', 'Otomatisasi untuk kenyamanan setiap hari.',
 'Paket otomatisasi TRIOMA Home Kit. Hub dan sensor bekerja bersama untuk menjalankan rutinitas rumah, seperti Mode Pergi dan Mode Pulang, tanpa perlu menyentuh aplikasi setiap saat.',
 650000, 20, 1,
 '[{"label":"Fokus","value":"Otomatisasi"},{"label":"Pengendali","value":"ESP32-S3"},{"label":"Pengembangan lanjutan","value":"Modul Zigbee"}]'),
('paket-jaga', 'Paket JAGA', 'package', 'Keamanan', 'Keamanan maksimal untuk keluarga Anda.',
 'Paket keamanan TRIOMA Home Kit. Pantau pintu dan gerakan, terima notifikasi saat ada kejadian, dan lihat riwayatnya kapan saja.',
 425000, 20, 2,
 '[{"label":"Fokus","value":"Keamanan"},{"label":"Pengendali","value":"ESP32-S3"},{"label":"Pengembangan lanjutan","value":"Modul Zigbee"}]'),
('paket-hemat', 'Paket HEMAT', 'package', 'Efisiensi energi', 'Efisiensi energi untuk masa depan.',
 'Paket efisiensi energi TRIOMA Home Kit. Kendalikan stop kontak pintar dan lihat pemakaian listrik per perangkat agar pemborosan mudah ditemukan.',
 650000, 20, 3,
 '[{"label":"Fokus","value":"Efisiensi energi"},{"label":"Pengendali","value":"ESP32-S3"},{"label":"Pengembangan lanjutan","value":"Modul Zigbee"}]'),
('trioma-cam', 'TRIOMA Cam', 'accessory', 'Pemantauan visual', 'Tambahan kamera untuk TRIOMA Home Kit.',
 'Kamera tambahan untuk melengkapi paket TRIOMA Home Kit.',
 175000, 20, 4,
 '[{"label":"Jenis","value":"Aksesori kamera"}]');

insert into product_costs (product_id, hpp_idr)
select id, case slug when 'paket-teras' then 450000 when 'paket-jaga' then 300000 when 'paket-hemat' then 450000 end
  from products where slug in ('paket-teras', 'paket-jaga', 'paket-hemat');

insert into product_packages (product_id, item_name, quantity, sort_order)
select p.id, v.item, v.qty, v.ord from products p join (values
  ('paket-teras', 'Hub TRIOMA', 1, 1), ('paket-teras', 'Sensor Gerak', 1, 2), ('paket-teras', 'Sensor Suhu', 1, 3),
  ('paket-jaga',  'Hub TRIOMA', 1, 1), ('paket-jaga',  'Sensor Pintu', 1, 2), ('paket-jaga', 'Sensor Gerak', 1, 3),
  ('paket-hemat', 'Hub TRIOMA', 1, 1), ('paket-hemat', 'Smart Switch', 1, 2), ('paket-hemat', 'Sensor Suhu', 1, 3)
) as v(slug, item, qty, ord) on v.slug = p.slug;

insert into system_settings (key, value) values
('site', '{"store_name":"TRIOMA Home Kit","whatsapp_number":"","contact_email":"","contact_address":""}'),
('announcement', '{"active":false,"text":""}');

-- ---------- PESAN KONTAK (publik, tanpa login) ----------
create or replace function submit_contact(p_name text, p_email text, p_message text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if char_length(coalesce(p_message, '')) < 10 or char_length(p_message) > 2000
     or char_length(coalesce(p_name, '')) < 2 or p_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    raise exception 'Data kontak tidak valid.';
  end if;
  insert into notifications (user_id, title, body, level)
  select id, 'Pesan kontak dari ' || left(p_name, 60), left(p_email, 120) || ': ' || left(p_message, 600), 'info'
    from profiles where role in ('admin', 'super_admin');
end $$;
grant execute on function submit_contact(text, text, text) to anon, authenticated;

-- Admin dapat menghapus perangkat (manajemen perangkat).
create policy "perangkat: admin hapus" on devices for delete using (is_admin());
